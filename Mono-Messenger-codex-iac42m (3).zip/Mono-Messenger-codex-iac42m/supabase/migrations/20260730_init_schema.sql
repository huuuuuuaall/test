CREATE EXTENSION IF NOT EXISTS pgcrypto;

create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  name text not null,
  avatar text,
  handle text unique not null,
  bio text,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

create table social_posts (
  id text primary key,
  author_id uuid references profiles(id) on delete cascade not null,
  body text not null,
  attachments jsonb default '[]' not null,
  stats jsonb default '{"likes": 0, "comments": 0, "reposts": 0, "saves": 0}' not null,
  reactions jsonb default '{}' not null,
  created_at timestamptz default now() not null
);

create table social_post_reactions (
  post_id text references social_posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  reaction text not null,
  primary key (post_id, user_id)
);

create table social_saved_posts (
  post_id text references social_posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  saved_at timestamptz default now() not null,
  primary key (post_id, user_id)
);

create table social_comments (
  id uuid primary key default gen_random_uuid(),
  post_id text references social_posts(id) on delete cascade not null,
  author_id uuid references profiles(id) on delete cascade not null,
  body text not null,
  created_at timestamptz default now() not null
);

create table social_reposts (
  post_id text references social_posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  reposted_at timestamptz default now() not null,
  primary key (post_id, user_id)
);

create table videos (
  id text primary key,
  author_id uuid references profiles(id) on delete cascade not null,
  video_url text not null,
  poster_url text,
  caption text,
  music text,
  stats jsonb default '{"likes": 0, "comments": 0, "reposts": 0, "saves": 0}' not null,
  created_at timestamptz default now() not null
);

create table video_likes (
  video_id text references videos(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  liked_at timestamptz default now() not null,
  primary key (video_id, user_id)
);

create table video_comments (
  id uuid primary key default gen_random_uuid(),
  video_id text references videos(id) on delete cascade not null,
  author_id uuid references profiles(id) on delete cascade not null,
  body text not null,
  created_at timestamptz default now() not null
);

create table video_reposts (
  video_id text references videos(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  reposted_at timestamptz default now() not null,
  primary key (video_id, user_id)
);

create table video_saves (
  video_id text references videos(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  saved_at timestamptz default now() not null,
  primary key (video_id, user_id)
);

create table user_follows (
  follower_id uuid references profiles(id) on delete cascade not null,
  following_id uuid references profiles(id) on delete cascade not null,
  followed_at timestamptz default now() not null,
  primary key (follower_id, following_id),
  check (follower_id != following_id)
);

create table channels (
  id text primary key,
  owner_id uuid references profiles(id) on delete cascade not null,
  title text not null,
  handle text unique not null,
  description text,
  visibility text check (visibility in ('public', 'private')) default 'public',
  cover_url text,
  verified boolean default false,
  stats jsonb default '{"subscribers": 0, "weeklyReach": 0, "engagementRate": 0, "posts": 0}' not null,
  created_at timestamptz default now() not null
);

create table channel_posts (
  id text primary key,
  channel_id text references channels(id) on delete cascade not null,
  author_id uuid references profiles(id) on delete cascade not null,
  title text not null,
  body text not null,
  comments_count int default 0 not null,
  reactions jsonb default '{}' not null,
  views int default 0 not null,
  created_at timestamptz default now() not null
);

create table channel_post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id text references channel_posts(id) on delete cascade not null,
  author_id uuid references profiles(id) on delete cascade not null,
  body text not null,
  created_at timestamptz default now() not null
);

create table channel_post_reactions (
  post_id text references channel_posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  reaction text not null,
  primary key (post_id, user_id)
);

create table messages (
  id uuid primary key default gen_random_uuid(),
  chat_id text not null,
  author_id uuid references profiles(id) on delete cascade not null,
  text text,
  media text,
  created_at timestamptz default now() not null
);

create table community_invites (
  id uuid primary key default gen_random_uuid(),
  community_id text not null,
  code text unique not null,
  expires_at timestamptz not null,
  uses int default 0 not null,
  max_uses int,
  created_at timestamptz default now() not null
);

create table community_members (
  community_id text not null,
  user_id uuid references profiles(id) on delete cascade not null,
  role text check (role in ('owner', 'admin', 'moderator', 'member')) default 'member',
  joined_at timestamptz default now() not null,
  primary key (community_id, user_id)
);

create table community_moderation_actions (
  id uuid primary key default gen_random_uuid(),
  community_id text not null,
  item_id text not null,
  action text not null,
  moderator_id uuid references profiles(id),
  created_at timestamptz default now() not null
);

create table community_chat_messages (
  id uuid primary key default gen_random_uuid(),
  community_id text not null,
  author_id uuid references profiles(id) on delete cascade not null,
  body text not null,
  created_at timestamptz default now() not null
);

create table community_posts (
  id uuid primary key default gen_random_uuid(),
  community_id text not null,
  author_id uuid references profiles(id) on delete cascade not null,
  title text not null,
  body text not null,
  created_at timestamptz default now() not null
);

create table community_videos (
  id uuid primary key default gen_random_uuid(),
  community_id text not null,
  author_id uuid references profiles(id) on delete cascade not null,
  video_url text not null,
  poster_url text,
  caption text,
  created_at timestamptz default now() not null
);

create index idx_social_posts_author on social_posts(author_id);
create index idx_social_comments_post on social_comments(post_id);
create index idx_social_comments_author on social_comments(author_id);
create index idx_video_comments_video on video_comments(video_id);
create index idx_video_comments_author on video_comments(author_id);
create index idx_user_follows_following on user_follows(following_id);
create index idx_messages_chat on messages(chat_id);
create index idx_messages_author on messages(author_id);
create index idx_community_chat_messages_community on community_chat_messages(community_id);
create index idx_community_posts_community on community_posts(community_id);
create index idx_community_videos_community on community_videos(community_id);
create index idx_channel_posts_channel on channel_posts(channel_id);
create index idx_channel_post_comments_post on channel_post_comments(post_id);
create index idx_community_invites_community on community_invites(community_id);
create index idx_community_members_community on community_members(community_id);
create index idx_community_moderation_community on community_moderation_actions(community_id);
create index idx_social_post_reactions_post on social_post_reactions(post_id);
create index idx_social_saved_posts_post on social_saved_posts(post_id);
create index idx_social_reposts_post on social_reposts(post_id);
create index idx_video_likes_video on video_likes(video_id);
create index idx_video_reposts_video on video_reposts(video_id);
create index idx_video_saves_video on video_saves(video_id);
create index idx_channel_post_reactions_post on channel_post_reactions(post_id);

alter table profiles enable row level security;
alter table social_posts enable row level security;
alter table social_post_reactions enable row level security;
alter table social_saved_posts enable row level security;
alter table social_comments enable row level security;
alter table social_reposts enable row level security;
alter table videos enable row level security;
alter table video_likes enable row level security;
alter table video_comments enable row level security;
alter table video_reposts enable row level security;
alter table video_saves enable row level security;
alter table user_follows enable row level security;
alter table channels enable row level security;
alter table channel_posts enable row level security;
alter table channel_post_comments enable row level security;
alter table channel_post_reactions enable row level security;
alter table messages enable row level security;
alter table community_invites enable row level security;
alter table community_members enable row level security;
alter table community_moderation_actions enable row level security;
alter table community_chat_messages enable row level security;
alter table community_posts enable row level security;
alter table community_videos enable row level security;

create policy "Profiles are viewable by everyone" on profiles for select using (true);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);
create policy "New users can create own profile" on profiles for insert with check (auth.uid() = id);

create or replace function handle_new_user() returns trigger as $$
begin
  insert into profiles (id, email, name, handle)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)), coalesce(new.raw_user_meta_data->>'handle', split_part(new.email, '@', 1) || new.id));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create policy "Social posts are viewable by everyone" on social_posts for select using (true);
create policy "Authenticated users can insert social posts" on social_posts for insert with check (auth.uid() = author_id);
create policy "Authors can update own social posts" on social_posts for update using (auth.uid() = author_id);

create policy "Social post reactions are viewable by everyone" on social_post_reactions for select using (true);
create policy "Authenticated users can react to posts" on social_post_reactions for insert with check (auth.uid() = user_id);
create policy "Users can remove own reactions" on social_post_reactions for delete using (auth.uid() = user_id);

create policy "Social saved posts are viewable by owner" on social_saved_posts for select using (auth.uid() = user_id);
create policy "Users can save posts" on social_saved_posts for insert with check (auth.uid() = user_id);
create policy "Users can unsave own posts" on social_saved_posts for delete using (auth.uid() = user_id);

create policy "Social comments are viewable by everyone" on social_comments for select using (true);
create policy "Authenticated users can comment" on social_comments for insert with check (auth.uid() = author_id);

create policy "Social reposts are viewable by everyone" on social_reposts for select using (true);
create policy "Authenticated users can repost" on social_reposts for insert with check (auth.uid() = user_id);
create policy "Users can remove own reposts" on social_reposts for delete using (auth.uid() = user_id);

create policy "Videos are viewable by everyone" on videos for select using (true);
create policy "Authenticated users can insert videos" on videos for insert with check (auth.uid() = author_id);
create policy "Authors can update own videos" on videos for update using (auth.uid() = author_id);

create policy "Video likes are viewable by everyone" on video_likes for select using (true);
create policy "Authenticated users can like videos" on video_likes for insert with check (auth.uid() = user_id);
create policy "Users can remove own likes" on video_likes for delete using (auth.uid() = user_id);

create policy "Video comments are viewable by everyone" on video_comments for select using (true);
create policy "Authenticated users can comment on videos" on video_comments for insert with check (auth.uid() = author_id);

create policy "Video reposts are viewable by everyone" on video_reposts for select using (true);
create policy "Authenticated users can repost videos" on video_reposts for insert with check (auth.uid() = user_id);

create policy "Video saves are viewable by owner" on video_saves for select using (auth.uid() = user_id);
create policy "Users can save videos" on video_saves for insert with check (auth.uid() = user_id);
create policy "Users can unsave own videos" on video_saves for delete using (auth.uid() = user_id);

create policy "User follows are viewable by everyone" on user_follows for select using (true);
create policy "Authenticated users can follow" on user_follows for insert with check (auth.uid() = follower_id);
create policy "Users can unfollow" on user_follows for delete using (auth.uid() = follower_id);

create policy "Channels are viewable by everyone" on channels for select using (true);
create policy "Authenticated users can create channels" on channels for insert with check (auth.uid() = owner_id);
create policy "Channel owners can update channels" on channels for update using (auth.uid() = owner_id);

create policy "Channel posts are viewable by everyone" on channel_posts for select using (true);
create policy "Authenticated users can publish posts" on channel_posts for insert with check (auth.uid() = author_id);

create policy "Channel post comments are viewable by everyone" on channel_post_comments for select using (true);
create policy "Authenticated users can comment on channel posts" on channel_post_comments for insert with check (auth.uid() = author_id);

create policy "Channel post reactions are viewable by everyone" on channel_post_reactions for select using (true);
create policy "Authenticated users can react to channel posts" on channel_post_reactions for insert with check (auth.uid() = user_id);

create policy "Messages are viewable by chat participants" on messages for select using (auth.uid() = author_id);
create policy "Authenticated users can send messages" on messages for insert with check (auth.uid() = author_id);

create policy "Community invites are viewable by community members" on community_invites for select using (community_id in (select community_id from community_members where user_id = auth.uid()));
create policy "Authenticated users can create invites" on community_invites for insert with check (community_id in (select community_id from community_members where user_id = auth.uid() and role in ('owner', 'admin')));

create policy "Community members are viewable by everyone" on community_members for select using (true);
create policy "Authenticated users can join communities" on community_members for insert with check (auth.uid() = user_id);
create policy "Members can update own role" on community_members for update using (auth.uid() = user_id);

create policy "Community moderation actions are viewable by community members" on community_moderation_actions for select using (community_id in (select community_id from community_members where user_id = auth.uid()));
create policy "Moderators can take actions" on community_moderation_actions for insert with check (community_id in (select community_id from community_members where user_id = auth.uid() and role in ('owner', 'admin', 'moderator')));

create policy "Community chat messages are viewable by community members" on community_chat_messages for select using (community_id in (select community_id from community_members where user_id = auth.uid()));
create policy "Community members can send messages" on community_chat_messages for insert with check (community_id in (select community_id from community_members where user_id = auth.uid()));

create policy "Community posts are viewable by community members" on community_posts for select using (community_id in (select community_id from community_members where user_id = auth.uid()));
create policy "Community members can create posts" on community_posts for insert with check (community_id in (select community_id from community_members where user_id = auth.uid()));

create policy "Community videos are viewable by community members" on community_videos for select using (community_id in (select community_id from community_members where user_id = auth.uid()));
create policy "Community members can upload videos" on community_videos for insert with check (community_id in (select community_id from community_members where user_id = auth.uid()));

create or replace function handle_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger profiles_updated_at before update on profiles for each row execute function handle_updated_at();