import { CameraView } from 'expo-camera';
import { router } from 'expo-router';
import { StyleSheet, View } from 'react-native';
import { Button, Card, Muted, Screen, Title } from '@/shared/ui/primitives';
export default function QrLogin() { return <Screen><View style={s.wrap}><Card><Title>QR вход</Title><Muted>Отсканируйте код на другом устройстве для безопасной авторизации.</Muted><View style={s.camera}><CameraView style={StyleSheet.absoluteFill} /></View><Button onPress={() => router.replace('/(tabs)/chats')}>Подтвердить вход</Button></Card></View></Screen>; }
const s = StyleSheet.create({ wrap: { flex: 1, justifyContent: 'center' }, camera: { height: 260, borderRadius: 30, overflow: 'hidden', marginTop: 18, backgroundColor: '#EEE' } });
