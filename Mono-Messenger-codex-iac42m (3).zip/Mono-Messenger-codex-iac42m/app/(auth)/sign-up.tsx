import { router } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { StyleSheet, View } from 'react-native';
import { Button, Card, Field, Muted, Screen, Title } from '@/shared/ui/primitives';
export default function SignUp() { const { control } = useForm({ defaultValues: { name: '', email: '', password: '' } }); return <Screen><View style={s.wrap}><Card><Title>Создание аккаунта</Title><Muted>Заполните информацию, чтобы присоединиться к Mono.</Muted>{(['name','email','password'] as const).map((name) => <Controller key={name} control={control} name={name} render={({ field }) => <Field placeholder={name === 'name' ? 'Имя' : name === 'email' ? 'Email' : 'Пароль'} secureTextEntry={name === 'password'} value={field.value} onChangeText={field.onChange} />} />)}<Button onPress={() => router.replace('/(tabs)/chats')}>Продолжить</Button></Card></View></Screen>; }
const s = StyleSheet.create({ wrap: { flex: 1, justifyContent: 'center' } });
