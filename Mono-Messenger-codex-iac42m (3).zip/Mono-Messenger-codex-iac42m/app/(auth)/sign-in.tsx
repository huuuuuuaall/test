import { router } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { StyleSheet, View } from 'react-native';
import { Button, Card, Field, Muted, Screen, Title } from '@/shared/ui/primitives';
export default function SignIn() { const { control } = useForm({ defaultValues: { email: 'example@mail.com', password: '' } }); return <Screen><View style={s.wrap}><Card><Title>Добро пожаловать</Title><Muted>Войдите в свой аккаунт или используйте QR-вход.</Muted><Controller control={control} name="email" render={({ field }) => <Field placeholder="Email" value={field.value} onChangeText={field.onChange} />} /><Controller control={control} name="password" render={({ field }) => <Field placeholder="Пароль" secureTextEntry value={field.value} onChangeText={field.onChange} />} /><Button onPress={() => router.replace('/(tabs)/chats')}>Войти</Button><Button onPress={() => router.push('/(auth)/sign-up')}>Зарегистрироваться</Button><Button onPress={() => router.push('/(auth)/qr')}>QR вход</Button></Card></View></Screen>; }
const s = StyleSheet.create({ wrap: { flex: 1, justifyContent: 'center' } });
