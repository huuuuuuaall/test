import { MonoHomeScreen } from '@/features/ecosystem';
export default MonoHomeScreen;
