import { MonoAiScreen } from '@/features/ai/screens/MonoAiScreen';
export default MonoAiScreen;
