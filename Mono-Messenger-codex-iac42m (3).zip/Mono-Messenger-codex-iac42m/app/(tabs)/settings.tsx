import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import { usePathname } from 'expo-router';
import { Avatar, Button, Card, Field, Muted, Screen, Title } from '@/shared/ui/primitives';
import { sparkPrivacySettings } from '@/features/messenger/model';
import { colors } from '@/shared/config/theme';

const map = { search: ['Поиск', 'Чаты, люди, файлы и медиа'], calls: ['Звонки', 'Аудио и видео звонки Mono'], profile: ['Иван Петров', '@ivanpetrov'], settings: ['Настройки', 'Аккаунт, устройства, уведомления'] } as const;

export default function Page() {
  const key = (usePathname().split('/').pop() ?? 'search') as keyof typeof map;
  const [title, sub] = map[key];

  return (
    <Screen>
      <Title>{title}</Title>
      <Muted>{sub}</Muted>
      {key === 'search' && <Field placeholder="Поиск" />}
      <View style={{ height: 18 }} />
      {key === 'profile' && <Card><View style={s.center}><Avatar label="Иван" size={92} /><Title>Иван Петров</Title><Muted>@ivanpetrov</Muted><Button>Редактировать профиль</Button></View></Card>}
      {key === 'calls' && ['Александр','Мария','Дизайн-команда'].map((name) => <Card key={name}><View style={s.row}><Avatar label={name} /><View style={{ flex: 1 }}><Text style={s.name}>{name}</Text><Muted>Сегодня, 12:30</Muted></View><Ionicons name="call" size={26} /></View></Card>)}
      {key === 'settings' && (
        <>
          {['Аккаунт','Устройства','Уведомления','Конфиденциальность','Оформление','Язык'].map((name) => <Card key={name}><View style={s.row}><Text style={s.name}>{name}</Text><Ionicons name="chevron-forward" size={22} color={colors.muted} /></View></Card>)}
          <View style={s.sparkSection}>
            <Text style={s.sectionTitle}>Приватность Огонька</Text>
            <Muted>Настройте, кто видит регулярность общения и какие сигналы засчитываются.</Muted>
            {sparkPrivacySettings.map((item) => (
              <Card key={item.id}>
                <View style={s.row}>
                  <View style={s.sparkIcon}><Text style={s.sparkIconText}>✦</Text></View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.name}>{item.title}</Text>
                    <Muted>{item.value}</Muted>
                  </View>
                  <Ionicons name="chevron-forward" size={22} color={colors.muted} />
                </View>
              </Card>
            ))}
          </View>
        </>
      )}
      {key === 'search' && ['Александр','Мария Петрова','Канал новостей'].map((name) => <Card key={name}><View style={s.row}><Avatar label={name} /><Text style={s.name}>{name}</Text></View></Card>)}
    </Screen>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 10 },
  name: { flex: 1, fontSize: 17, fontWeight: '800' },
  center: { alignItems: 'center', gap: 10 },
  sparkSection: { marginTop: 16, gap: 10 },
  sectionTitle: { color: colors.ink, fontSize: 20, fontWeight: '900' },
  sparkIcon: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#FF7A1A', alignItems: 'center', justifyContent: 'center' },
  sparkIconText: { color: 'white', fontSize: 18, fontWeight: '900' },
});
