import { FlashList } from '@shopify/flash-list';
import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { useEffect } from 'react';
import { Avatar, Card, Field, Screen, Title } from '@/shared/ui/primitives';
import { chats, myThought, thoughts, type Chat, type SparkActivity, type Thought } from '@/features/messenger/model';
import { colors } from '@/shared/config/theme';

const thoughtIcon: Record<Thought['kind'], string> = {
  text: 'Aa',
  emoji: '😊',
  gif: 'GIF',
  photo: '📷',
};

const openThoughtReply = (chatId: string) => {
  if (chatId !== 'me') {
    router.push({ pathname: '/chat/[id]', params: { id: chatId, thought: '1' } });
  }
};


function SparkBadge({ spark }: { spark: SparkActivity }) {
  const pulse = useSharedValue(1);

  useEffect(() => {
    pulse.value = withRepeat(withSequence(withTiming(1.16, { duration: 900 }), withTiming(1, { duration: 900 })), -1, true);
  }, [pulse]);

  const pulseStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));
  const glow = spark.intensity === 3 ? '#FF7A1A' : spark.intensity === 2 ? '#FFB020' : '#FFD166';

  return (
    <Animated.View entering={FadeIn.duration(450)} style={[s.sparkBadge, { backgroundColor: glow }, pulseStyle]}>
      <Text style={s.sparkIcon}>ᗧ</Text>
      <Text style={s.sparkDays}>{spark.days}</Text>
    </Animated.View>
  );
}

function ThoughtBubble({ thought, compact = false }: { thought: Thought; compact?: boolean }) {
  return (
    <View style={[s.thoughtBubble, compact && s.compactThoughtBubble]}>
      <Text style={s.thoughtIcon}>{thoughtIcon[thought.kind]}</Text>
      {!compact ? <Text numberOfLines={1} style={s.thoughtText}>{thought.text}</Text> : null}
    </View>
  );
}

function ThoughtStrip() {
  return (
    <View style={s.stripBlock}>
      <View style={s.stripHead}>
        <Text style={s.sectionTitle}>Мысли</Text>
        <Text style={s.ttl}>исчезают через 24 часа</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.strip}>
        <Pressable style={s.myThoughtCard}>
          <View style={s.addCircle}><Text style={s.addText}>+</Text></View>
          <Text style={s.stripName}>Ваша мысль</Text>
          <Text numberOfLines={1} style={s.stripPreview}>{myThought.text}</Text>
        </Pressable>
        {thoughts.filter((thought) => thought.chatId !== 'me').map((thought) => (
          <Pressable key={thought.id} style={s.thoughtCard} onPress={() => openThoughtReply(thought.chatId)}>
            <Avatar label={thought.author} size={54} />
            <ThoughtBubble thought={thought} />
            <Text numberOfLines={1} style={s.stripName}>{thought.author}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <View style={s.publisher}>
        {['Текст', 'Эмодзи', 'GIF', 'Фото'].map((item) => <Text key={item} style={s.publisherChip}>{item}</Text>)}
      </View>
    </View>
  );
}

function ChatRow({ item }: { item: Chat }) {
  return (
    <Pressable onPress={() => router.push(`/chat/${item.id}`)}>
      <Card>
        <View style={s.row}>
          <View>
            <Avatar label={item.title} />
            {item.thought ? <View style={s.avatarThought}><ThoughtBubble thought={item.thought} compact /></View> : null}
            {item.spark ? <View style={s.avatarSpark}><SparkBadge spark={item.spark} /></View> : null}
          </View>
          <View style={s.body}>
            <View style={s.nameRow}>
              <Text style={s.name}>{item.title}</Text>
              {item.thought ? <Text style={s.hasThought}>мысль</Text> : null}
              {item.spark ? <Text style={s.hasSpark}>Огонёк {item.spark.days}д</Text> : null}
            </View>
            <Text style={s.sub}>{item.spark ? item.spark.notification : item.subtitle}</Text>
          </View>
          <View style={s.badge}><Text style={s.badgeText}>{item.unread}</Text></View>
        </View>
      </Card>
    </Pressable>
  );
}

export default function Chats() {
  return (
    <Screen>
      <Title>Чаты</Title>
      <Field placeholder="Поиск" />
      <FlashList
        data={chats}
        estimatedItemSize={112}
        ListHeaderComponent={<ThoughtStrip />}
        renderItem={({ item }) => <ChatRow item={item} />}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
      />
    </Screen>
  );
}

const s = StyleSheet.create({
  stripBlock: { marginTop: 18, marginBottom: 14 },
  stripHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 20, fontWeight: '900', color: colors.ink },
  ttl: { color: colors.muted, fontSize: 12, fontWeight: '700' },
  strip: { gap: 12, paddingRight: 20 },
  myThoughtCard: { width: 116, minHeight: 132, borderRadius: 26, padding: 14, backgroundColor: colors.ink, justifyContent: 'space-between' },
  thoughtCard: { width: 116, minHeight: 132, borderRadius: 26, padding: 14, backgroundColor: '#FFFFFF', alignItems: 'center', gap: 8 },
  addCircle: { width: 42, height: 42, borderRadius: 21, backgroundColor: 'white', alignItems: 'center', justifyContent: 'center' },
  addText: { fontSize: 28, fontWeight: '800', color: colors.ink, marginTop: -2 },
  stripName: { fontWeight: '800', color: colors.ink, textAlign: 'center' },
  stripPreview: { color: '#D9D8E8', fontSize: 12 },
  publisher: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  publisherChip: { overflow: 'hidden', borderRadius: 14, paddingHorizontal: 12, paddingVertical: 7, color: colors.violet, backgroundColor: '#EFEBFF', fontWeight: '800' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  body: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { fontSize: 17, fontWeight: '800' },
  hasThought: { color: colors.violet, fontSize: 12, fontWeight: '900' },
  sub: { color: colors.muted, marginTop: 4 },
  badge: { backgroundColor: colors.violet, borderRadius: 12, minWidth: 24, height: 24, alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: 'white', fontWeight: '800' },
  thoughtBubble: { maxWidth: 100, borderRadius: 18, backgroundColor: '#F2EEFF', paddingHorizontal: 10, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 4 },
  compactThoughtBubble: { position: 'absolute', right: -10, bottom: -4, borderWidth: 2, borderColor: 'white', paddingHorizontal: 6, paddingVertical: 4 },
  thoughtIcon: { color: colors.violet, fontWeight: '900', fontSize: 12 },
  thoughtText: { color: colors.ink, fontSize: 12, fontWeight: '700' },
  avatarThought: { position: 'absolute', right: -2, bottom: 0 },
  avatarSpark: { position: 'absolute', left: -5, top: -6 },
  sparkBadge: { minWidth: 34, height: 24, borderRadius: 12, borderWidth: 2, borderColor: 'white', paddingHorizontal: 6, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 2 },
  sparkIcon: { color: 'white', fontWeight: '900', fontSize: 12 },
  sparkDays: { color: 'white', fontWeight: '900', fontSize: 12 },
  hasSpark: { color: '#FF7A1A', fontSize: 12, fontWeight: '900' },
});
