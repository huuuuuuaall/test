import { CommunitiesScreen } from '@/features/communities/screens/CommunitiesScreen';
export default CommunitiesScreen;
