import { ChannelsScreen } from '@/features/channels/screens/ChannelsScreen';
export default ChannelsScreen;
