import { SocialFeedScreen } from '@/features/social/screens/SocialFeedScreen';
export default SocialFeedScreen;
