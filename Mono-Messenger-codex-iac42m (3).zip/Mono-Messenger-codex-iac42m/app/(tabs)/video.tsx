import { VideoFeedScreen } from '@/features/video/screens/VideoFeedScreen';
export default VideoFeedScreen;
