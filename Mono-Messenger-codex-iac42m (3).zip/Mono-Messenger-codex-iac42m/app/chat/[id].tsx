import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams } from 'expo-router';
import Animated, { FadeInDown, useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { Avatar, Card, Field, Screen, Title } from '@/shared/ui/primitives';
import { chats, messages, type SparkActivity, type Thought } from '@/features/messenger/model';
import { colors } from '@/shared/config/theme';

const thoughtIcon: Record<Thought['kind'], string> = {
  text: 'Aa',
  emoji: '😊',
  gif: 'GIF',
  photo: '📷',
};


const signalLabels: Record<SparkActivity['signals'][number]['kind'], string> = {
  message: 'Сообщения',
  reaction: 'Реакции',
  shared_action: 'Совместно',
};

function SparkPanel({ spark }: { spark: SparkActivity }) {
  const pulse = useSharedValue(1);

  useEffect(() => {
    pulse.value = withRepeat(withSequence(withTiming(1.04, { duration: 1200 }), withTiming(1, { duration: 1200 })), -1, true);
  }, [pulse]);

  const pulseStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));

  return (
    <Animated.View entering={FadeInDown.springify()} style={[s.sparkPanel, pulseStyle]}>
      <View style={s.sparkTop}>
        <View>
          <Text style={s.sparkEyebrow}>Огонёк активности</Text>
          <Text style={s.sparkTitle}>{spark.days} дней рядом</Text>
        </View>
        <View style={s.sparkOrb}><Text style={s.sparkOrbText}>✦</Text></View>
      </View>
      <Text style={s.sparkNotice}>{spark.notification}</Text>
      <View style={s.signalGrid}>
        {spark.signals.map((signal) => (
          <View key={signal.id} style={s.signalChip}>
            <Text style={s.signalKind}>{signalLabels[signal.kind]}</Text>
            <Text style={s.signalLabel}>{signal.label}</Text>
          </View>
        ))}
      </View>
      <Text style={s.privacyHint}>Приватность: {spark.privacy === 'everyone' ? 'видно всем' : spark.privacy === 'contacts' ? 'только контакты' : 'скрыто'}</Text>
    </Animated.View>
  );
}

function ThoughtBadge({ thought }: { thought: Thought }) {
  return (
    <View style={s.thoughtBadge}>
      <Text style={s.thoughtIcon}>{thoughtIcon[thought.kind]}</Text>
    </View>
  );
}

function ReplyPrompt({ thought }: { thought: Thought }) {
  return (
    <Card>
      <View style={s.replyPrompt}>
        <View style={s.replyIcon}><Text style={s.replyIconText}>{thoughtIcon[thought.kind]}</Text></View>
        <View style={s.replyBody}>
          <Text style={s.replyTitle}>Ответ на мысль</Text>
          <Text style={s.replyText}>{thought.text}</Text>
          <Text style={s.replyTtl}>Мысль будет удалена автоматически через 24 часа после публикации.</Text>
        </View>
      </View>
    </Card>
  );
}

export default function Chat() {
  const { id, thought } = useLocalSearchParams<{ id: string; thought?: string }>();
  const chat = chats.find((c) => c.id === id) ?? chats[0];
  const showThoughtReply = thought === '1' && Boolean(chat.thought);

  return (
    <Screen>
      <View style={s.head}>
        <View>
          <Avatar label={chat.title} size={44} />
          {chat.thought ? <ThoughtBadge thought={chat.thought} /> : null}
          {chat.spark ? <View style={s.headerSpark}><Text style={s.headerSparkText}>{chat.spark.days}</Text></View> : null}
        </View>
        <View style={s.titleBlock}>
          <Title>{chat.title}</Title>
          {chat.spark ? <Text style={s.sparkLine}>{chat.spark.label}</Text> : null}
          {chat.thought ? <Text style={s.thoughtLine}>Есть мысль: {chat.thought.text}</Text> : null}
        </View>
        <Ionicons name="call" size={26} />
      </View>
      {chat.spark ? <SparkPanel spark={chat.spark} /> : null}
      {showThoughtReply && chat.thought ? <View style={s.promptWrap}><ReplyPrompt thought={chat.thought} /></View> : null}
      <FlashList
        data={messages.filter((m) => m.chatId === chat.id)}
        estimatedItemSize={60}
        renderItem={({ item }) => (
          <View style={[s.bubble, item.author === 'me' ? s.me : s.them]}>
            <Text style={item.author === 'me' && { color: 'white' }}>{item.text}</Text>
            <Text style={[s.time, item.author === 'me' && { color: '#DDD' }]}>{item.time}</Text>
          </View>
        )}
      />
      <Field placeholder={showThoughtReply ? 'Ответить на мысль...' : 'Сообщение...'} />
    </Screen>
  );
}

const s = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
  titleBlock: { flex: 1 },
  sparkLine: { color: '#FF7A1A', fontSize: 12, fontWeight: '900', marginTop: -2 },
  thoughtLine: { color: colors.violet, fontSize: 12, fontWeight: '800', marginTop: 2 },
  thoughtBadge: { position: 'absolute', right: -6, bottom: -4, minWidth: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: 'white', backgroundColor: '#F2EEFF', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  thoughtIcon: { color: colors.violet, fontWeight: '900', fontSize: 11 },
  headerSpark: { position: 'absolute', left: -8, top: -8, minWidth: 25, height: 25, borderRadius: 13, borderWidth: 2, borderColor: 'white', backgroundColor: '#FF7A1A', alignItems: 'center', justifyContent: 'center' },
  headerSparkText: { color: 'white', fontSize: 11, fontWeight: '900' },
  sparkPanel: { marginBottom: 12, borderRadius: 28, padding: 16, backgroundColor: '#221208' },
  sparkTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sparkEyebrow: { color: '#FFD8A8', fontSize: 12, fontWeight: '900', textTransform: 'uppercase' },
  sparkTitle: { color: 'white', fontSize: 24, fontWeight: '900', marginTop: 2 },
  sparkOrb: { width: 48, height: 48, borderRadius: 24, backgroundColor: '#FF7A1A', alignItems: 'center', justifyContent: 'center' },
  sparkOrbText: { color: 'white', fontSize: 24, fontWeight: '900' },
  sparkNotice: { color: '#FFE5C2', marginTop: 12, fontWeight: '700' },
  signalGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  signalChip: { flexGrow: 1, flexBasis: '30%', borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.1)', padding: 10 },
  signalKind: { color: '#FFD8A8', fontSize: 11, fontWeight: '900' },
  signalLabel: { color: 'white', fontSize: 12, fontWeight: '700', marginTop: 4 },
  privacyHint: { color: '#FFD8A8', fontSize: 12, marginTop: 12, fontWeight: '700' },
  promptWrap: { marginBottom: 12 },
  replyPrompt: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  replyIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#EFEBFF', alignItems: 'center', justifyContent: 'center' },
  replyIconText: { color: colors.violet, fontWeight: '900' },
  replyBody: { flex: 1 },
  replyTitle: { fontSize: 16, fontWeight: '900', color: colors.ink },
  replyText: { color: colors.ink, marginTop: 3, fontWeight: '700' },
  replyTtl: { color: colors.muted, marginTop: 4, fontSize: 12 },
  bubble: { maxWidth: '78%', padding: 14, borderRadius: 22, marginVertical: 6 },
  me: { alignSelf: 'flex-end', backgroundColor: colors.violet },
  them: { alignSelf: 'flex-start', backgroundColor: '#EFEFF4' },
  time: { fontSize: 11, color: colors.muted, marginTop: 4 },
});
