import { router } from 'expo-router';
import { Image, StyleSheet, View } from 'react-native';
import { Button, Card, Muted, Screen, Title } from '@/shared/ui/primitives';
export default function Onboarding() { return <Screen><View style={s.wrap}><Card><View style={s.hero}><Title>Безопасный мессенджер</Title><Muted>Общайтесь с друзьями в стильном защищённом пространстве Mono.</Muted></View><Button onPress={() => router.push('/(auth)/sign-in')}>Начать</Button></Card></View></Screen>; }
const s = StyleSheet.create({ wrap: { flex: 1, justifyContent: 'center' }, hero: { minHeight: 220, justifyContent: 'center', alignItems: 'center', gap: 12 } });
