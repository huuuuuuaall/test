export type SocialAttachment =
  | { type: 'photo'; uri: string; alt: string }
  | { type: 'video'; uri: string; poster: string; duration: string }
  | { type: 'gif'; uri: string; alt: string }
  | { type: 'link'; url: string; title: string; description: string; image?: string }
  | { type: 'poll'; question: string; options: Array<{ id: string; label: string; votes: number }>; votedOptionId?: string };

export type Reaction = 'like' | 'love' | 'fire' | 'wow' | 'sad';

export type SocialPost = {
  id: string;
  author: { id: string; name: string; handle: string; avatar: string };
  body: string;
  createdAt: string;
  attachments: SocialAttachment[];
  stats: { likes: number; comments: number; reposts: number; saves: number };
  reactions: Partial<Record<Reaction, number>>;
  viewer: { liked: boolean; saved: boolean; reaction?: Reaction };
};
