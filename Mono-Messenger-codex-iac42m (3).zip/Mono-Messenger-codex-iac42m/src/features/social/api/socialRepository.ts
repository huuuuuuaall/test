import { supabase } from '@/shared/api/supabase';
import { SocialPost, Reaction } from '../model';

const demoPosts: SocialPost[] = [
  { id: 'social-1', author: { id: 'u1', name: 'Мария Петрова', handle: '@maria', avatar: 'М' }, body: 'Mono Social начинается с тихой, красивой ленты: фотографии, видео, GIF, ссылки и опросы в одном премиальном пространстве.', createdAt: '2 мин', attachments: [{ type: 'photo', uri: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200', alt: 'Minimal workspace' }], stats: { likes: 128, comments: 24, reposts: 12, saves: 42 }, reactions: { love: 58, fire: 31, wow: 17 }, viewer: { liked: false, saved: true, reaction: 'love' } },
  { id: 'social-2', author: { id: 'u2', name: 'Mono Design', handle: '@mono.design', avatar: 'D' }, body: 'Какой формат должен стать главным в социальной платформе Mono?', createdAt: '18 мин', attachments: [{ type: 'poll', question: 'Выберите фокус следующего релиза', options: [{ id: 'p1', label: 'Посты и комьюнити', votes: 42 }, { id: 'p2', label: 'Видео-платформа', votes: 35 }, { id: 'p3', label: 'AI-рекомендации', votes: 23 }], votedOptionId: 'p1' }], stats: { likes: 86, comments: 19, reposts: 8, saves: 13 }, reactions: { like: 44, fire: 22 }, viewer: { liked: true, saved: false, reaction: 'fire' } },
  { id: 'social-3', author: { id: 'u3', name: 'Александр', handle: '@alex', avatar: 'А' }, body: 'Видео, GIF и внешние материалы отображаются как отдельные вложения, поэтому модуль можно развивать независимо от мессенджера.', createdAt: '1 ч', attachments: [{ type: 'video', uri: 'https://mono.example/video.mp4', poster: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=1200', duration: '00:19' }, { type: 'gif', uri: 'https://media.giphy.com/media/3o7aD2saalBwwftBIY/giphy.gif', alt: 'Celebration animation' }, { type: 'link', url: 'https://mono.social', title: 'Mono Social Platform', description: 'Будущая социальная платформа поверх идеального мессенджера.', image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200' }], stats: { likes: 211, comments: 48, reposts: 33, saves: 75 }, reactions: { like: 80, love: 64, wow: 29 }, viewer: { liked: false, saved: false } },
];

export const socialRepository = {
  listPosts: async () => demoPosts,
  listProfilePosts: async (userId: string) => demoPosts.filter((post) => post.author.id === userId || userId === 'me'),
  listProfileReposts: async (userId: string) => demoPosts.filter((_, index) => userId === 'me' && index % 2 === 0),
  listProfileMedia: async (userId: string) => demoPosts.filter((post) => post.author.id === userId || userId === 'me').flatMap((post) => post.attachments.filter((attachment) => attachment.type === 'photo' || attachment.type === 'gif' || attachment.type === 'video').map((attachment) => ({ postId: post.id, attachment }))),
  reactToPost: async (postId: string, reaction: Reaction) => supabase.from('social_post_reactions').upsert({ post_id: postId, reaction }),
  toggleSave: async (postId: string, saved: boolean) => saved ? supabase.from('social_saved_posts').insert({ post_id: postId }) : supabase.from('social_saved_posts').delete().eq('post_id', postId),
  addComment: async (postId: string, body: string) => supabase.from('social_comments').insert({ post_id: postId, body }),
  repost: async (postId: string) => supabase.from('social_reposts').insert({ post_id: postId }),
  subscribeFeed: (onChange: () => void) => supabase.channel('social:feed').on('postgres_changes', { event: '*', schema: 'public', table: 'social_posts' }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'social_post_reactions' }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'social_comments' }, onChange).subscribe(),
};
