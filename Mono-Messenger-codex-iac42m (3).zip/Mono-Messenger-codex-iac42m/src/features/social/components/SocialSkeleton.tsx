import { StyleSheet, View } from 'react-native';
import Animated, { FadeIn, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { Card } from '@/shared/ui/primitives';

export function SocialSkeleton() {
  const opacity = useSharedValue(0.45);
  opacity.value = withRepeat(withTiming(1, { duration: 900 }), -1, true);
  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return <Animated.View entering={FadeIn} style={animatedStyle}><Card><View style={s.row}><View style={s.avatar} /><View style={{ flex: 1 }}><View style={s.line} /><View style={[s.line, { width: '45%' }]} /></View></View><View style={s.media} /><View style={s.actions} /></Card></Animated.View>;
}
const s = StyleSheet.create({ row: { flexDirection: 'row', gap: 14, alignItems: 'center' }, avatar: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#E9E9EF' }, line: { height: 12, borderRadius: 6, backgroundColor: '#E9E9EF', marginBottom: 10 }, media: { height: 220, borderRadius: 28, backgroundColor: '#E9E9EF', marginTop: 18 }, actions: { height: 44, borderRadius: 22, backgroundColor: '#EFEFF4', marginTop: 16 } });
