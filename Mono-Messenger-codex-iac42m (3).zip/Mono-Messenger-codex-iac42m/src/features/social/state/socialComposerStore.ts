import { create } from 'zustand';
import { SocialAttachment } from '../model';

type SocialComposerState = {
  text: string;
  attachments: SocialAttachment[];
  setText: (text: string) => void;
  addAttachment: (attachment: SocialAttachment) => void;
  reset: () => void;
};

export const useSocialComposerStore = create<SocialComposerState>((set) => ({
  text: '',
  attachments: [],
  setText: (text) => set({ text }),
  addAttachment: (attachment) => set((state) => ({ attachments: [...state.attachments, attachment] })),
  reset: () => set({ text: '', attachments: [] }),
}));
