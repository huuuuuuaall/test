# Social feature

Feature-first module for Mono Social. It owns feed screens, post cards, composer state, repository calls, and Supabase Realtime subscriptions.

Suggested Supabase tables: `social_posts`, `social_post_media`, `social_post_reactions`, `social_comments`, `social_reposts`, and `social_saved_posts`.
