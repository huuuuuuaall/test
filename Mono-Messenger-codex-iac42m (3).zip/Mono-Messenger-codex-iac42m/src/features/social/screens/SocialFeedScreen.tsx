import { FlashList } from '@shopify/flash-list';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { RefreshControl, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { Button, Card, Field, Muted, Screen, Title } from '@/shared/ui/primitives';
import { colors } from '@/shared/config/theme';
import { socialRepository } from '../api/socialRepository';
import { PostCard } from '../components/PostCard';
import { SocialSkeleton } from '../components/SocialSkeleton';

export function SocialFeedScreen() {
  const queryClient = useQueryClient();
  const postsQuery = useQuery({ queryKey: ['social', 'feed'], queryFn: socialRepository.listPosts });
  useEffect(() => { const channel = socialRepository.subscribeFeed(() => queryClient.invalidateQueries({ queryKey: ['social', 'feed'] })); return () => { channel.unsubscribe(); }; }, [queryClient]);
  return <Screen><Animated.View entering={FadeInDown.springify()} style={s.hero}><View><Title>Social</Title><Muted>Премиальная лента Mono для постов, фото, видео, GIF, опросов и ссылок.</Muted></View><Button>Создать пост</Button></Animated.View><Card><Text style={s.composerTitle}>Что нового?</Text><Field placeholder="Поделитесь моментом, ссылкой или опросом" /></Card>{postsQuery.isLoading ? <View style={s.loading}><SocialSkeleton /><SocialSkeleton /></View> : <FlashList data={postsQuery.data ?? []} estimatedItemSize={520} refreshControl={<RefreshControl refreshing={postsQuery.isFetching} onRefresh={() => postsQuery.refetch()} tintColor={colors.violet} />} renderItem={({ item, index }) => <PostCard post={item} index={index} />} ItemSeparatorComponent={() => <View style={{ height: 16 }} />} showsVerticalScrollIndicator={false} />}</Screen>;
}
const s = StyleSheet.create({ hero: { gap: 16, marginBottom: 16 }, composerTitle: { fontSize: 18, fontWeight: '900', color: colors.ink }, loading: { gap: 16 } });
