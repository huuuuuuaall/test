import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius } from '@/shared/config/theme';
import { ProfileTab } from '../model';

const labels: Record<ProfileTab, string> = { posts: 'Посты', videos: 'Видео', reposts: 'Репосты', media: 'Медиа' };
export function ProfileTabs({ value, onChange }: { value: ProfileTab; onChange: (tab: ProfileTab) => void }) {
  return <View style={s.wrap}>{(Object.keys(labels) as ProfileTab[]).map((tab) => <Pressable key={tab} onPress={() => onChange(tab)} style={[s.tab, value === tab && s.active]}><Text style={[s.text, value === tab && s.activeText]}>{labels[tab]}</Text></Pressable>)}</View>;
}
const s = StyleSheet.create({ wrap: { flexDirection: 'row', gap: 8, marginVertical: 16 }, tab: { flex: 1, height: 44, borderRadius: radius.md, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' }, active: { backgroundColor: colors.ink }, text: { color: colors.muted, fontWeight: '900' }, activeText: { color: 'white' } });
