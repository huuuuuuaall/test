import { Image, ImageBackground, StyleSheet, Text, View } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { Card, Muted } from '@/shared/ui/primitives';
import { colors, radius } from '@/shared/config/theme';
import { socialRepository } from '@/features/social/api/socialRepository';
import { videoRepository } from '@/features/video/api/videoRepository';
import { ProfileTab } from '../model';

export function ProfileContentGrid({ userId, tab }: { userId: string; tab: ProfileTab }) {
  const postsQuery = useQuery({ queryKey: ['profile', 'posts', userId], queryFn: () => socialRepository.listProfilePosts(userId) });
  const repostsQuery = useQuery({ queryKey: ['profile', 'reposts', userId], queryFn: () => socialRepository.listProfileReposts(userId) });
  const mediaQuery = useQuery({ queryKey: ['profile', 'media', userId], queryFn: () => socialRepository.listProfileMedia(userId) });
  const videosQuery = useQuery({ queryKey: ['profile', 'videos', userId], queryFn: () => videoRepository.listProfileVideos(userId) });
  if (tab === 'videos') return <View style={s.grid}>{(videosQuery.data ?? []).map((video) => <ImageBackground key={video.id} source={{ uri: video.posterUrl }} imageStyle={s.image} style={s.videoTile}><View style={s.overlay}><Text style={s.white}>▶ {video.stats.likes}</Text></View></ImageBackground>)}</View>;
  if (tab === 'media') return <View style={s.grid}>{(mediaQuery.data ?? []).map((item, index) => item.attachment.type === 'video' ? <View key={`${item.postId}-${index}`} style={s.mediaTile}><Text style={s.mediaIcon}>▶</Text></View> : <Image key={`${item.postId}-${index}`} source={{ uri: item.attachment.uri }} style={s.mediaTile} />)}</View>;
  const posts = tab === 'reposts' ? repostsQuery.data : postsQuery.data;
  return <View style={s.list}>{(posts ?? []).map((post) => <Card key={post.id}><Text style={s.postBody}>{post.body}</Text><Muted>❤️ {post.stats.likes} · 💬 {post.stats.comments} · ↗ {post.stats.reposts}</Muted></Card>)}</View>;
}
const s = StyleSheet.create({ grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, list: { gap: 12 }, videoTile: { width: '31%', aspectRatio: 0.72, borderRadius: radius.md, overflow: 'hidden', justifyContent: 'flex-end', backgroundColor: '#ECECF1' }, mediaTile: { width: '31%', aspectRatio: 1, borderRadius: radius.md, backgroundColor: '#ECECF1' }, image: { borderRadius: radius.md }, overlay: { padding: 8, backgroundColor: 'rgba(0,0,0,0.22)' }, white: { color: 'white', fontWeight: '900' }, mediaIcon: { color: colors.violet, fontSize: 28, fontWeight: '900', textAlign: 'center', marginTop: 44 }, postBody: { color: colors.ink, fontSize: 16, lineHeight: 23, fontWeight: '700', marginBottom: 10 } });
