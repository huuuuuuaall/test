import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { Muted, Screen, Title } from '@/shared/ui/primitives';
import { profileRepository } from '../api/profileRepository';
import { ProfileContentGrid } from '../components/ProfileContentGrid';
import { ProfileHeader } from '../components/ProfileHeader';
import { ProfileTabs } from '../components/ProfileTabs';
import { ProfileTab } from '../model';

export function ProfileScreen() {
  const [tab, setTab] = useState<ProfileTab>('posts');
  const profileQuery = useQuery({ queryKey: ['profile', 'me'], queryFn: profileRepository.getCurrentProfile });
  if (!profileQuery.data) return <Screen><View style={s.empty}><Title>Профиль</Title><Muted>Загружаем профиль…</Muted></View></Screen>;
  return <Screen><ScrollView showsVerticalScrollIndicator={false}><ProfileHeader profile={profileQuery.data} /><ProfileTabs value={tab} onChange={setTab} /><ProfileContentGrid userId={profileQuery.data.id} tab={tab} /><View style={{ height: 32 }} /></ScrollView></Screen>;
}
const s = StyleSheet.create({ empty: { flex: 1, justifyContent: 'center' } });
