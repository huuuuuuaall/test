export type ProfileLink = { label: string; url: string };
export type ActivityStat = { label: string; value: string; delta: string };
export type UserProfile = {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bannerUrl: string;
  bio: string;
  links: ProfileLink[];
  followers: number;
  following: number;
  activity: ActivityStat[];
};
export type ProfileTab = 'posts' | 'videos' | 'reposts' | 'media';
