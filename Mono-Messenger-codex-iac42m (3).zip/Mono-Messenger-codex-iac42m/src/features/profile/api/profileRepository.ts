import { UserProfile } from '../model';

const me: UserProfile = {
  id: 'me',
  name: 'Иван Петров',
  handle: '@ivanpetrov',
  avatar: 'И',
  bannerUrl: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1600',
  bio: 'Создаю премиальные цифровые продукты, делюсь заметками о дизайне, видео и будущем Mono.',
  links: [{ label: 'mono.social/ivan', url: 'https://mono.social/ivan' }, { label: 'Портфолио', url: 'https://ivan.design' }],
  followers: 12840,
  following: 356,
  activity: [
    { label: 'Постов за неделю', value: '18', delta: '+24%' },
    { label: 'Просмотры видео', value: '48.2K', delta: '+12%' },
    { label: 'Вовлечённость', value: '9.8%', delta: '+3.1%' },
  ],
};

export const profileRepository = { getCurrentProfile: async () => me };
