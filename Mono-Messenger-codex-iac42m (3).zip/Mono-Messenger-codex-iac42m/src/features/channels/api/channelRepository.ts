import { supabase } from '@/shared/api/supabase';
import { Channel } from '../model';

const channels: Channel[] = [
  { id: 'mono-news', title: 'Mono News', handle: '@mono.news', description: 'Публичный канал о релизах Mono, продукте и безопасности.', visibility: 'public', coverUrl: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200', verified: true, stats: { subscribers: 48200, weeklyReach: 128000, engagementRate: 12.4, posts: 86 }, posts: [{ id: 'cp1', channelId: 'mono-news', title: 'Mono Social Alpha', body: 'Запускаем каналы, сообщества и модульную социальную платформу.', createdAt: 'Сегодня', comments: 84, reactions: { like: 420, fire: 190, insight: 72 }, views: 12400 }] },
  { id: 'product-lab', title: 'Product Lab', handle: '@product.lab', description: 'Приватный канал команды для публикаций и обсуждений.', visibility: 'private', coverUrl: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200', stats: { subscribers: 128, weeklyReach: 2100, engagementRate: 28.1, posts: 34 }, posts: [{ id: 'cp2', channelId: 'product-lab', title: 'Новый профиль', body: 'Собираем реакции по вкладкам профиля и видео-сетке.', createdAt: 'Вчера', comments: 16, reactions: { love: 48, insight: 22 }, views: 890 }] },
];

export const channelRepository = {
  listChannels: async () => channels,
  listPosts: async (channelId: string) => channels.find((channel) => channel.id === channelId)?.posts ?? [],
  publishPost: async (channelId: string, post: { title: string; body: string }) => supabase.from('channel_posts').insert({ channel_id: channelId, ...post }),
  addComment: async (postId: string, body: string) => supabase.from('channel_post_comments').insert({ post_id: postId, body }),
  react: async (postId: string, reaction: string) => supabase.from('channel_post_reactions').upsert({ post_id: postId, reaction }),
  subscribe: (onChange: () => void) => supabase.channel('channels').on('postgres_changes', { event: '*', schema: 'public', table: 'channels' }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'channel_posts' }, onChange).subscribe(),
};
