import { FlashList } from '@shopify/flash-list';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { View } from 'react-native';
import { Button, Muted, Screen, Title } from '@/shared/ui/primitives';
import { channelRepository } from '../api/channelRepository';
import { ChannelCard } from '../components/ChannelCard';

export function ChannelsScreen() {
  const queryClient = useQueryClient();
  const channelsQuery = useQuery({ queryKey: ['channels'], queryFn: channelRepository.listChannels });
  useEffect(() => { const channel = channelRepository.subscribe(() => queryClient.invalidateQueries({ queryKey: ['channels'] })); return () => { channel.unsubscribe(); }; }, [queryClient]);
  return <Screen><Title>Каналы</Title><Muted>Публичные и приватные каналы с публикациями, комментариями, реакциями и статистикой.</Muted><Button>Создать канал</Button><FlashList data={channelsQuery.data ?? []} estimatedItemSize={420} renderItem={({ item, index }) => <ChannelCard channel={item} index={index} />} ItemSeparatorComponent={() => <View style={{ height: 14 }} />} showsVerticalScrollIndicator={false} /></Screen>;
}
