export type ChannelVisibility = 'public' | 'private';
export type ChannelReaction = 'like' | 'love' | 'fire' | 'insight';
export type ChannelPost = { id: string; channelId: string; title: string; body: string; createdAt: string; comments: number; reactions: Partial<Record<ChannelReaction, number>>; views: number };
export type ChannelStats = { subscribers: number; weeklyReach: number; engagementRate: number; posts: number };
export type Channel = { id: string; title: string; handle: string; description: string; visibility: ChannelVisibility; coverUrl: string; verified?: boolean; stats: ChannelStats; posts: ChannelPost[] };
