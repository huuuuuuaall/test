# Channels feature

Standalone module for public/private channels, channel publications, comments, reactions, and statistics. Suggested Supabase tables: `channels`, `channel_posts`, `channel_post_comments`, `channel_post_reactions`, `channel_post_stats`.
