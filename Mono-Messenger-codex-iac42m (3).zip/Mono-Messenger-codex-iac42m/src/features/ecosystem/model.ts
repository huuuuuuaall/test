import { ComponentProps } from 'react';
import { Ionicons } from '@expo/vector-icons';

export type MonoModuleId = 'messenger' | 'social' | 'video' | 'channels' | 'communities' | 'ai' | 'profile' | 'search' | 'settings';
export type MonoRoute = '/chats' | '/social' | '/video' | '/channels' | '/communities' | '/ai' | '/profile' | '/search' | '/settings';

export type MonoModule = {
  id: MonoModuleId;
  title: string;
  subtitle: string;
  route: MonoRoute;
  icon: ComponentProps<typeof Ionicons>['name'];
  accent: string;
  metric: string;
};

export type EcosystemCheck = {
  id: string;
  title: string;
  status: 'ready' | 'watch';
  description: string;
};

export const monoModules: MonoModule[] = [
  { id: 'messenger', title: 'Мессенджер', subtitle: 'Чаты, мысли и Огонёк', route: '/chats', icon: 'chatbubbles', accent: '#7C5CFF', metric: 'Realtime' },
  { id: 'social', title: 'Социальная сеть', subtitle: 'Посты и реакции', route: '/social', icon: 'sparkles', accent: '#FF4D8D', metric: 'Feed' },
  { id: 'video', title: 'Видео', subtitle: 'Короткие ролики', route: '/video', icon: 'play-circle', accent: '#FF7A1A', metric: '60fps' },
  { id: 'channels', title: 'Каналы', subtitle: 'Публикации брендов', route: '/channels', icon: 'radio', accent: '#34C759', metric: 'Broadcast' },
  { id: 'communities', title: 'Сообщества', subtitle: 'Группы по интересам', route: '/communities', icon: 'people', accent: '#00A3FF', metric: 'Clubs' },
  { id: 'ai', title: 'Mono AI', subtitle: 'Помощник внутри экосистемы', route: '/ai', icon: 'sparkles-outline', accent: '#111113', metric: 'Assist' },
  { id: 'profile', title: 'Профили', subtitle: 'Личность и контент', route: '/profile', icon: 'person-circle', accent: '#A996FF', metric: 'Identity' },
  { id: 'search', title: 'Поиск', subtitle: 'Люди, файлы, медиа', route: '/search', icon: 'search', accent: '#5856D6', metric: 'Global' },
  { id: 'settings', title: 'Настройки', subtitle: 'Безопасность и приватность', route: '/settings', icon: 'settings', accent: '#777A83', metric: 'Control' },
];

export const ecosystemChecks: EcosystemCheck[] = [
  { id: 'architecture', title: 'Архитектура', status: 'ready', description: 'Фичи разделены по доменам, общий слой UI и API используется как единая платформа.' },
  { id: 'performance', title: 'Производительность', status: 'ready', description: 'Ленты используют FlashList, а запросы кэшируются через React Query.' },
  { id: 'security', title: 'Безопасность', status: 'ready', description: 'Сессии Supabase хранятся в AsyncStorage, включены автообновление токена и безопасный anon-key через env.' },
  { id: 'animations', title: 'Анимации', status: 'ready', description: 'Карточки и социальные индикаторы используют Reanimated без блокировки основного потока.' },
  { id: 'navigation', title: 'Навигация', status: 'ready', description: 'Все модули доступны из единого хаба и нижней навигации.' },
  { id: 'supabase', title: 'Supabase', status: 'watch', description: 'Клиент централизован; production URL и anon key должны приходить из окружения.' },
  { id: 'scale', title: 'Масштабируемость', status: 'ready', description: 'Новые продукты добавляются как feature-модули и регистрируются в каталоге экосистемы.' },
];
