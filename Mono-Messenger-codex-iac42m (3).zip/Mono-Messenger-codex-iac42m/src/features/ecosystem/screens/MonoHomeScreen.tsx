import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { Card, Muted, Screen, Title } from '@/shared/ui/primitives';
import { colors, radius } from '@/shared/config/theme';
import { ecosystemChecks, monoModules, type EcosystemCheck, type MonoModule } from '../model';

function ModuleCard({ item, index }: { item: MonoModule; index: number }) {
  return (
    <Pressable onPress={() => router.push(item.route)} style={s.modulePressable}>
      <Animated.View entering={FadeInDown.delay(index * 35).springify()} style={s.moduleCard}>
        <View style={[s.moduleIcon, { backgroundColor: item.accent }]}>
          <Ionicons name={item.icon} size={22} color="white" />
        </View>
        <Text style={s.moduleTitle}>{item.title}</Text>
        <Text style={s.moduleSubtitle}>{item.subtitle}</Text>
        <Text style={[s.moduleMetric, { color: item.accent }]}>{item.metric}</Text>
      </Animated.View>
    </Pressable>
  );
}

function CheckRow({ item }: { item: EcosystemCheck }) {
  const ready = item.status === 'ready';
  return (
    <View style={s.checkRow}>
      <View style={[s.checkDot, { backgroundColor: ready ? colors.green : '#FFB020' }]} />
      <View style={{ flex: 1 }}>
        <Text style={s.checkTitle}>{item.title}</Text>
        <Text style={s.checkDescription}>{item.description}</Text>
      </View>
    </View>
  );
}

export function MonoHomeScreen() {
  return (
    <Screen>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={s.hero}>
          <Text style={s.eyebrow}>Mono ecosystem</Text>
          <Title>Единое премиальное приложение</Title>
          <Muted>Мессенджер, социальная сеть, видео, каналы, сообщества, AI, профили, поиск и настройки связаны общим UX, навигацией и инфраструктурой.</Muted>
          <View style={s.heroStats}>
            <View style={s.stat}><Text style={s.statValue}>9</Text><Text style={s.statLabel}>модулей</Text></View>
            <View style={s.stat}><Text style={s.statValue}>1</Text><Text style={s.statLabel}>экосистема</Text></View>
            <View style={s.stat}><Text style={s.statValue}>∞</Text><Text style={s.statLabel}>масштаб</Text></View>
          </View>
        </View>

        <Text style={s.sectionTitle}>Продукты Mono</Text>
        <View style={s.moduleGrid}>
          {monoModules.map((item, index) => <ModuleCard key={item.id} item={item} index={index} />)}
        </View>

        <View style={s.sectionGap}>
          <Card>
            <Text style={s.sectionTitle}>Проверка целостности</Text>
            <Muted>Базовый аудит архитектуры, производительности, безопасности, анимаций, навигации, Supabase и масштабируемости.</Muted>
            <View style={s.checks}>{ecosystemChecks.map((item) => <CheckRow key={item.id} item={item} />)}</View>
          </Card>
        </View>
        <View style={{ height: 30 }} />
      </ScrollView>
    </Screen>
  );
}

const s = StyleSheet.create({
  hero: { paddingVertical: 8 },
  eyebrow: { color: colors.violet, fontSize: 13, fontWeight: '900', textTransform: 'uppercase', marginBottom: 8 },
  heroStats: { flexDirection: 'row', gap: 10, marginTop: 18 },
  stat: { flex: 1, borderRadius: radius.md, backgroundColor: '#FFFFFF', padding: 14 },
  statValue: { color: colors.ink, fontSize: 24, fontWeight: '900' },
  statLabel: { color: colors.muted, fontSize: 12, fontWeight: '800', marginTop: 2 },
  sectionTitle: { color: colors.ink, fontSize: 20, fontWeight: '900', marginBottom: 12 },
  moduleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  modulePressable: { width: '48%' },
  moduleCard: { minHeight: 168, borderRadius: radius.lg, padding: 16, backgroundColor: '#FFFFFF', justifyContent: 'space-between' },
  moduleIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  moduleTitle: { color: colors.ink, fontSize: 17, fontWeight: '900', marginTop: 12 },
  moduleSubtitle: { color: colors.muted, fontSize: 13, lineHeight: 18, marginTop: 4 },
  moduleMetric: { fontSize: 12, fontWeight: '900', marginTop: 10 },
  sectionGap: { marginTop: 18 },
  checks: { gap: 14, marginTop: 16 },
  checkRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  checkDot: { width: 12, height: 12, borderRadius: 6, marginTop: 4 },
  checkTitle: { color: colors.ink, fontWeight: '900', fontSize: 15 },
  checkDescription: { color: colors.muted, lineHeight: 19, marginTop: 3 },
});
