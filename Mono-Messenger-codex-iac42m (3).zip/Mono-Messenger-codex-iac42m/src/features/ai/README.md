# Mono AI feature

Standalone AI section powered by OpenRouter chat completions. It supports model selection, web search via OpenRouter `:online`/web plugin, deep-thinking request options, streaming responses, Markdown rendering, sources, chat history, pin/rename/delete, and file/image attachments.

Required environment variable: `EXPO_PUBLIC_OPENROUTER_API_KEY`.
