import { StyleSheet, Text, View } from 'react-native';
import Markdown from 'react-native-markdown-display';
import { colors, radius } from '@/shared/config/theme';
import { AiMessage } from '../model';

export function MarkdownMessage({ message }: { message: AiMessage }) {
  const isUser = message.role === 'user';
  const markdownBodyStyle = isUser ? s.markdownUser : s.markdown;
  return <View style={[s.bubble, isUser ? s.user : s.assistant]}><Markdown style={{ body: markdownBodyStyle, code_inline: s.code, fence: s.fence }}>{message.content || (message.streaming ? 'Mono AI думает…' : '')}</Markdown>{Boolean(message.attachments?.length) && <Text style={[s.attachments, isUser ? s.userText : undefined]}>📎 {message.attachments?.map((item) => item.name).join(', ')}</Text>}{Boolean(message.sources?.length) && <View style={s.sources}>{message.sources?.map((source) => <Text key={source.url} style={s.source}>↗ {source.title}: {source.url}</Text>)}</View>}</View>;
}
const s = StyleSheet.create({ bubble: { borderRadius: radius.lg, padding: 16, marginVertical: 7, maxWidth: '88%' }, user: { alignSelf: 'flex-end', backgroundColor: colors.violet }, assistant: { alignSelf: 'flex-start', backgroundColor: '#FFFFFF' }, markdown: { color: colors.ink, fontSize: 16, lineHeight: 23 }, markdownUser: { color: 'white', fontSize: 16, lineHeight: 23 }, userText: { color: 'white' }, code: { backgroundColor: '#ECECF1', borderRadius: 8, paddingHorizontal: 6 }, fence: { backgroundColor: '#111113', color: 'white', borderRadius: 14, padding: 12 }, attachments: { marginTop: 8, fontWeight: '800' }, sources: { marginTop: 12, gap: 6 }, source: { color: colors.violet, fontWeight: '700' } });
