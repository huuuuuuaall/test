import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius } from '@/shared/config/theme';
import { aiModels } from '../api/openRouterClient';

export function AiModelPicker({ modelId, onChange }: { modelId: string; onChange: (modelId: string) => void }) {
  return <View style={s.wrap}>{aiModels.map((model) => <Pressable key={model.id} onPress={() => onChange(model.id)} style={[s.model, model.id === modelId && s.active]}><Text style={s.title}>{model.title}</Text><Text style={s.subtitle}>{model.subtitle}</Text></Pressable>)}</View>;
}
const s = StyleSheet.create({ wrap: { gap: 8 }, model: { borderRadius: radius.md, backgroundColor: '#FFFFFF', padding: 12, borderWidth: 1, borderColor: '#FFFFFF' }, active: { borderColor: colors.violet, backgroundColor: '#F3F0FF' }, title: { fontWeight: '900', color: colors.ink }, subtitle: { color: colors.muted, marginTop: 3, fontSize: 12 } });
