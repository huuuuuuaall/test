import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, TextInput, View } from 'react-native';
import { colors, radius } from '@/shared/config/theme';
import { AiAttachment } from '../model';

export function AiComposer({ value, onChangeText, onSend, onAttach }: { value: string; onChangeText: (value: string) => void; onSend: () => void; onAttach: (attachments: AiAttachment[]) => void }) {
  const pickFile = async () => { const result = await DocumentPicker.getDocumentAsync({ multiple: true, copyToCacheDirectory: true }); if (!result.canceled) onAttach(result.assets.map((asset) => ({ id: asset.uri, name: asset.name, uri: asset.uri, mimeType: asset.mimeType, type: 'file' }))); };
  const pickImage = async () => { const result = await ImagePicker.launchImageLibraryAsync({ allowsMultipleSelection: true, mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.9, base64: false }); if (!result.canceled) onAttach(result.assets.map((asset) => ({ id: asset.uri, name: asset.fileName ?? 'image', uri: asset.uri, mimeType: asset.mimeType, type: 'image' }))); };
  return <View style={s.wrap}><Pressable onPress={pickFile} style={s.icon}><Ionicons name="document-attach-outline" size={22} /></Pressable><Pressable onPress={pickImage} style={s.icon}><Ionicons name="image-outline" size={22} /></Pressable><TextInput value={value} onChangeText={onChangeText} placeholder="Спросите Mono AI…" placeholderTextColor="#A5A7B0" multiline style={s.input} /><Pressable onPress={onSend} style={s.send}><Ionicons name="arrow-up" color="white" size={22} /></Pressable></View>;
}
const s = StyleSheet.create({ wrap: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, padding: 10, borderRadius: radius.lg, backgroundColor: '#FFFFFF' }, input: { flex: 1, minHeight: 42, maxHeight: 120, fontSize: 16, paddingVertical: 10 }, icon: { width: 42, height: 42, borderRadius: 16, backgroundColor: '#F2F2F6', alignItems: 'center', justifyContent: 'center' }, send: { width: 42, height: 42, borderRadius: 16, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center' } });
