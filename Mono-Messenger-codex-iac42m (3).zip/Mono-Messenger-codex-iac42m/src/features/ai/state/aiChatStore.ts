import { MMKV } from 'react-native-mmkv';
import { create } from 'zustand';
import { AiAttachment, AiChat, AiChatOptions, AiMessage } from '../model';

const storage = new MMKV({ id: 'mono-ai' });
const CHAT_KEY = 'ai.chats';
const now = () => Date.now();
const createId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;

const initialChat = (): AiChat => ({ id: createId(), title: 'Новый чат', modelId: 'google/gemma-4-31b-it:free', pinned: false, createdAt: now(), updatedAt: now(), messages: [] });
const loadChats = () => { const raw = storage.getString(CHAT_KEY); return raw ? (JSON.parse(raw) as AiChat[]) : [initialChat()]; };
const saveChats = (chats: AiChat[]) => storage.set(CHAT_KEY, JSON.stringify(chats));

type AiState = {
  chats: AiChat[];
  activeChatId: string;
  options: AiChatOptions;
  createChat: () => string;
  setActiveChat: (id: string) => void;
  renameChat: (id: string, title: string) => void;
  togglePin: (id: string) => void;
  deleteChat: (id: string) => void;
  setModel: (id: string, modelId: string) => void;
  setOptions: (options: Partial<AiChatOptions>) => void;
  addMessage: (chatId: string, message: Omit<AiMessage, 'id'>) => string;
  updateMessage: (chatId: string, messageId: string, patch: Partial<AiMessage>) => void;
  addAttachments: (chatId: string, attachments: AiAttachment[]) => void;
};

const persisted = loadChats();
export const useAiChatStore = create<AiState>((set, get) => ({
  chats: persisted,
  activeChatId: persisted[0].id,
  options: { webSearch: false, deepThinking: false },
  createChat: () => { const chat = initialChat(); set((state) => { const chats = [chat, ...state.chats]; saveChats(chats); return { chats, activeChatId: chat.id }; }); return chat.id; },
  setActiveChat: (activeChatId) => set({ activeChatId }),
  renameChat: (id, title) => set((state) => { const chats = state.chats.map((chat) => chat.id === id ? { ...chat, title, updatedAt: now() } : chat); saveChats(chats); return { chats }; }),
  togglePin: (id) => set((state) => { const chats = state.chats.map((chat) => chat.id === id ? { ...chat, pinned: !chat.pinned, updatedAt: now() } : chat).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt); saveChats(chats); return { chats }; }),
  deleteChat: (id) => set((state) => { const chats = state.chats.filter((chat) => chat.id !== id); const fallback = chats[0] ?? initialChat(); const nextChats = chats.length ? chats : [fallback]; saveChats(nextChats); return { chats: nextChats, activeChatId: state.activeChatId === id ? fallback.id : state.activeChatId }; }),
  setModel: (id, modelId) => set((state) => { const chats = state.chats.map((chat) => chat.id === id ? { ...chat, modelId, updatedAt: now() } : chat); saveChats(chats); return { chats }; }),
  setOptions: (options) => set((state) => ({ options: { ...state.options, ...options } })),
  addMessage: (chatId, message) => { const id = createId(); set((state) => { const chats = state.chats.map((chat) => chat.id === chatId ? { ...chat, title: chat.messages.length ? chat.title : message.content.slice(0, 34) || chat.title, updatedAt: now(), messages: [...chat.messages, { ...message, id }] } : chat); saveChats(chats); return { chats }; }); return id; },
  updateMessage: (chatId, messageId, patch) => set((state) => { const chats = state.chats.map((chat) => chat.id === chatId ? { ...chat, updatedAt: now(), messages: chat.messages.map((message) => message.id === messageId ? { ...message, ...patch } : message) } : chat); saveChats(chats); return { chats }; }),
  addAttachments: (chatId, attachments) => { const messageId = get().addMessage(chatId, { role: 'user', content: 'Вложения загружены', attachments }); return messageId; },
}));
