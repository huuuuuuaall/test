import { AiAttachment, AiChatOptions, AiMessage, AiModel, AiSource } from '../model';

const OPENROUTER_URL = process.env.EXPO_PUBLIC_OPENROUTER_URL ?? 'https://openrouter.ai/api/v1/chat/completions';
const apiKey = process.env.EXPO_PUBLIC_OPENROUTER_API_KEY;

export const aiModels: AiModel[] = [
  { id: 'google/gemma-4-31b-it:free', title: 'Gemma 4 31B', subtitle: 'Бесплатная модель Google для общих задач', supportsVision: true, supportsReasoning: true },
  { id: 'anthropic/claude-sonnet-4.5', title: 'Claude Sonnet 4.5', subtitle: 'Сильный анализ и длинный контекст', supportsVision: true, supportsReasoning: true },
  { id: 'google/gemini-2.5-pro', title: 'Gemini 2.5 Pro', subtitle: 'Мультимодальность и исследование', supportsVision: true, supportsReasoning: true },
  { id: 'openrouter/auto', title: 'Auto', subtitle: 'OpenRouter выберет оптимальную модель' },
];

const toOpenRouterContent = (message: AiMessage) => {
  const parts: Array<Record<string, unknown>> = [{ type: 'text', text: message.content }];
  message.attachments?.forEach((attachment) => {
    if (attachment.type === 'image') parts.push({ type: 'image_url', image_url: { url: attachment.uri } });
    else parts.push({ type: 'file', file: { filename: attachment.name, file_data: attachment.uri } });
  });
  return parts;
};

const extractSources = (payload: Record<string, unknown>): AiSource[] => {
  const annotations = JSON.stringify(payload).match(/https?:\/\/[^\s"'\\)]+/g) ?? [];
  return [...new Set(annotations)].slice(0, 6).map((url, index) => ({ title: `Источник ${index + 1}`, url }));
};

export async function streamOpenRouterChat(input: { modelId: string; messages: AiMessage[]; options: AiChatOptions; onToken: (token: string) => void; onSources: (sources: AiSource[]) => void }) {
  if (!apiKey) throw new Error('EXPO_PUBLIC_OPENROUTER_API_KEY is not configured');
  const response = await fetch(OPENROUTER_URL, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', 'HTTP-Referer': 'https://mono.social', 'X-Title': 'Mono AI' },
    body: JSON.stringify({ model: input.options.webSearch ? `${input.modelId}:online` : input.modelId, stream: true, reasoning: input.options.deepThinking ? { effort: 'high' } : undefined, plugins: input.options.webSearch ? [{ id: 'web', max_results: 5 }] : undefined, messages: input.messages.map((message) => ({ role: message.role, content: toOpenRouterContent(message) })) }),
  });
  if (!response.ok || !response.body) throw new Error(`OpenRouter request failed: ${response.status}`);
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  const sources: AiSource[] = [];
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6).trim();
      if (data === '[DONE]') continue;
      const payload = JSON.parse(data);
      const token = payload.choices?.[0]?.delta?.content ?? '';
      if (token) input.onToken(token);
      sources.push(...extractSources(payload));
    }
  }
  input.onSources([...new Map(sources.map((source) => [source.url, source])).values()]);
}
