import { FlashList } from '@shopify/flash-list';
import { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { colors } from '@/shared/config/theme';
import { Muted, Screen, Title } from '@/shared/ui/primitives';
import { streamOpenRouterChat } from '../api/openRouterClient';
import { AiChatHistory } from '../components/AiChatHistory';
import { AiComposer } from '../components/AiComposer';
import { AiModelPicker } from '../components/AiModelPicker';
import { MarkdownMessage } from '../components/MarkdownMessage';
import { AiAttachment } from '../model';
import { useAiChatStore } from '../state/aiChatStore';

export function MonoAiScreen() {
  const [draft, setDraft] = useState('');
  const { chats, activeChatId, options, createChat, setActiveChat, renameChat, togglePin, deleteChat, setModel, setOptions, addMessage, updateMessage, addAttachments } = useAiChatStore();
  const activeChat = useMemo(() => chats.find((chat) => chat.id === activeChatId) ?? chats[0], [activeChatId, chats]);
  const send = async () => {
    const content = draft.trim();
    if (!content) return;
    setDraft('');
    addMessage(activeChat.id, { role: 'user', content });
    const assistantId = addMessage(activeChat.id, { role: 'assistant', content: '', streaming: true });
    const messages = [...activeChat.messages, { id: 'local-user', role: 'user' as const, content }];
    try {
      await streamOpenRouterChat({ modelId: activeChat.modelId, messages, options, onToken: (token) => { const current = useAiChatStore.getState().chats.find((chat) => chat.id === activeChat.id)?.messages.find((message) => message.id === assistantId)?.content ?? ''; updateMessage(activeChat.id, assistantId, { content: current + token, streaming: true }); }, onSources: (sources) => updateMessage(activeChat.id, assistantId, { sources, streaming: false }) });
    } catch (error) {
      updateMessage(activeChat.id, assistantId, { content: `Не удалось получить ответ OpenRouter. Проверьте API key и сеть.\n\n${String(error)}`, streaming: false });
    }
  };
  const attach = (attachments: AiAttachment[]) => addAttachments(activeChat.id, attachments);
  return <Screen><Animated.View entering={FadeInDown.springify()} style={s.header}><View><Title>Mono AI</Title><Muted>Полноценный AI-раздел: модели, поиск, reasoning, файлы, изображения и источники.</Muted></View></Animated.View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.toggles}><Toggle label="Интернет-поиск" active={options.webSearch} onPress={() => setOptions({ webSearch: !options.webSearch })} /><Toggle label="Глубокое мышление" active={options.deepThinking} onPress={() => setOptions({ deepThinking: !options.deepThinking })} /></ScrollView><View style={s.layout}><View style={s.sidebar}><AiChatHistory chats={chats} activeChatId={activeChat.id} onSelect={setActiveChat} onNew={createChat} onPin={togglePin} onRename={(id) => renameChat(id, `Чат ${new Date().toLocaleTimeString()}`)} onDelete={deleteChat} /><AiModelPicker modelId={activeChat.modelId} onChange={(modelId) => setModel(activeChat.id, modelId)} /></View><View style={s.chat}><FlashList data={activeChat.messages} estimatedItemSize={130} renderItem={({ item }) => <MarkdownMessage message={item} />} ListEmptyComponent={<View style={s.empty}><Text style={s.emptyTitle}>Начните диалог</Text><Muted>Создайте чат, выберите модель, включите интернет-поиск или глубокое мышление.</Muted></View>} /><AiComposer value={draft} onChangeText={setDraft} onSend={send} onAttach={attach} /></View></View></Screen>;
}
function Toggle({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) { return <Pressable onPress={onPress} style={[s.toggle, active && s.toggleActive]}><Text style={[s.toggleText, active && s.toggleTextActive]}>{label}</Text></Pressable>; }
const s = StyleSheet.create({ header: { marginBottom: 12 }, toggles: { gap: 10, paddingBottom: 12 }, toggle: { height: 40, borderRadius: 20, backgroundColor: '#FFFFFF', paddingHorizontal: 16, justifyContent: 'center' }, toggleActive: { backgroundColor: colors.ink }, toggleText: { color: colors.ink, fontWeight: '800' }, toggleTextActive: { color: 'white' }, layout: { flex: 1, gap: 12 }, sidebar: { maxHeight: 220, gap: 10 }, chat: { flex: 1, gap: 10 }, empty: { alignItems: 'center', padding: 28 }, emptyTitle: { fontSize: 22, fontWeight: '900', color: colors.ink, marginBottom: 6 } });
