export type AiModel = { id: string; title: string; subtitle: string; supportsVision?: boolean; supportsReasoning?: boolean };
export type AiAttachment = { id: string; name: string; type: 'image' | 'file'; uri: string; mimeType?: string };
export type AiSource = { title: string; url: string; snippet?: string };
export type AiMessage = { id: string; role: 'user' | 'assistant'; content: string; attachments?: AiAttachment[]; sources?: AiSource[]; streaming?: boolean };
export type AiChat = { id: string; title: string; modelId: string; pinned: boolean; createdAt: number; updatedAt: number; messages: AiMessage[] };
export type AiChatOptions = { webSearch: boolean; deepThinking: boolean };
