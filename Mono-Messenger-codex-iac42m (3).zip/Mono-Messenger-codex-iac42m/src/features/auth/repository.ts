import { supabase } from '@/shared/api/supabase';
export type SignInInput = { email: string; password: string };
export const authRepository = {
  signIn: (input: SignInInput) => supabase.auth.signInWithPassword(input),
  signUp: (input: SignInInput & { name: string }) => supabase.auth.signUp({ email: input.email, password: input.password, options: { data: { name: input.name } } }),
  signInWithQrToken: (token: string) => supabase.functions.invoke('qr-login', { body: { token } }),
  signOut: () => supabase.auth.signOut(),
};
