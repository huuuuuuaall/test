export type RecommendationKind = 'post' | 'video' | 'user' | 'channel' | 'community';
export type UserInterest = 'design' | 'product' | 'security' | 'ai' | 'video' | 'communities';
export type RecommendationSignals = { likes: number; comments: number; follows: number; saves: number; views: number; videoWatchSeconds: number; interestMatches: number };
export type RecommendationItem = { id: string; kind: RecommendationKind; title: string; subtitle: string; imageUrl?: string; score: number; reasons: string[]; signals: RecommendationSignals };
export type UserRecommendationProfile = { userId: string; interests: UserInterest[]; followedAuthorIds: string[]; followedChannelIds: string[]; savedItemIds: string[]; recentViews: Record<string, number>; videoWatchSeconds: Record<string, number> };
