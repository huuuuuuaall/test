# Recommendations feature

Standalone For You module. The scoring engine combines likes, comments, follows, saves, views, video watch time, and user interests to recommend posts, videos, users, channels, and communities.
