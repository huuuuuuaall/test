import { StyleSheet, Text, View } from 'react-native';
import { Card, Muted } from '@/shared/ui/primitives';
import { colors, radius } from '@/shared/config/theme';
import { UserRecommendationProfile } from '../model';

export function RecommendationSignalPanel({ profile }: { profile: UserRecommendationProfile }) {
  return <Card><Text style={s.title}>Почему именно это?</Text><Muted>Алгоритм учитывает лайки, комментарии, подписки, сохранения, просмотры, время просмотра видео и интересы пользователя.</Muted><View style={s.interests}>{profile.interests.map((interest) => <Text key={interest} style={s.interest}>{interest}</Text>)}</View></Card>;
}
const s = StyleSheet.create({ title: { color: colors.ink, fontWeight: '900', fontSize: 18 }, interests: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 }, interest: { overflow: 'hidden', borderRadius: radius.md, backgroundColor: '#F6F6FA', paddingHorizontal: 12, paddingVertical: 8, color: colors.ink, fontWeight: '800' } });
