import { FlashList } from '@shopify/flash-list';
import { useQuery } from '@tanstack/react-query';
import { View } from 'react-native';
import { Muted, Screen, Title } from '@/shared/ui/primitives';
import { recommendationEngine } from '../api/recommendationEngine';
import { RecommendationCard } from '../components/RecommendationCard';
import { RecommendationSignalPanel } from '../components/RecommendationSignalPanel';

export function ForYouScreen() {
  const profileQuery = useQuery({ queryKey: ['recommendations', 'profile'], queryFn: recommendationEngine.getCurrentProfile });
  const recommendationsQuery = useQuery({ queryKey: ['recommendations', 'for-you'], queryFn: recommendationEngine.buildForYou });
  return <Screen><Title>Для вас</Title><Muted>Персональные рекомендации постов, видео, пользователей, каналов и сообществ.</Muted>{profileQuery.data && <RecommendationSignalPanel profile={profileQuery.data} />}<FlashList data={recommendationsQuery.data ?? []} estimatedItemSize={310} renderItem={({ item, index }) => <RecommendationCard item={item} index={index} />} ItemSeparatorComponent={() => <View style={{ height: 14 }} />} showsVerticalScrollIndicator={false} /></Screen>;
}
