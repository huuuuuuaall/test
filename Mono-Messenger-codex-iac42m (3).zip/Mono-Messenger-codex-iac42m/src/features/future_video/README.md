Reserved feature module for video platform built on React Native Video and Supabase Storage.
