import { FlashList } from '@shopify/flash-list';
import { useQuery } from '@tanstack/react-query';
import { View } from 'react-native';
import { Button, Muted, Screen, Title } from '@/shared/ui/primitives';
import { communityRepository } from '../api/communityRepository';
import { CommunityCard } from '../components/CommunityCard';

export function CommunitiesScreen() {
  const communitiesQuery = useQuery({ queryKey: ['communities'], queryFn: communityRepository.listCommunities });
  return <Screen><Title>Сообщества</Title><Muted>Чат, посты, видео, роли, модерация, приглашения и правила в одном независимом модуле.</Muted><Button>Создать сообщество</Button><FlashList data={communitiesQuery.data ?? []} estimatedItemSize={520} renderItem={({ item, index }) => <CommunityCard community={item} index={index} />} ItemSeparatorComponent={() => <View style={{ height: 14 }} />} showsVerticalScrollIndicator={false} /></Screen>;
}
