# Communities feature

Standalone module for community chat, posts, videos, roles, moderation, invitations, and rules. Suggested Supabase tables: `communities`, `community_chat_messages`, `community_posts`, `community_videos`, `community_members`, `community_invites`, `community_rules`, `community_moderation_actions`.
