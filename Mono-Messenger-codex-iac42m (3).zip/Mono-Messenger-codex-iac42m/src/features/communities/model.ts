export type CommunityRole = 'owner' | 'admin' | 'moderator' | 'member';
export type ModerationStatus = 'open' | 'reviewing' | 'resolved';
export type CommunityRule = { id: string; title: string; description: string };
export type CommunityInvite = { id: string; code: string; expiresAt: string; uses: number };
export type Community = { id: string; title: string; description: string; coverUrl: string; members: number; roles: Record<CommunityRole, number>; rules: CommunityRule[]; invites: CommunityInvite[]; moderation: { queue: number; status: ModerationStatus }; stats: { chatMessages: number; posts: number; videos: number } };
