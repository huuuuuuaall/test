import { supabase } from '@/shared/api/supabase';
import { Community } from '../model';

const communities: Community[] = [
  { id: 'design-hub', title: 'Design Hub', description: 'Сообщество дизайнеров Mono: чат, посты, видео и еженедельные разборы.', coverUrl: 'https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=1200', members: 18400, roles: { owner: 1, admin: 4, moderator: 12, member: 18383 }, rules: [{ id: 'r1', title: 'Уважение', description: 'Критикуем идеи, а не людей.' }, { id: 'r2', title: 'Без спама', description: 'Публикуем только полезные материалы.' }], invites: [{ id: 'i1', code: 'DESIGN-2026', expiresAt: '2026-12-31', uses: 128 }], moderation: { queue: 7, status: 'reviewing' }, stats: { chatMessages: 98200, posts: 1240, videos: 318 } },
  { id: 'founders', title: 'Founders Club', description: 'Приватное сообщество основателей: стратегии, видео и закрытые обсуждения.', coverUrl: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1200', members: 940, roles: { owner: 1, admin: 3, moderator: 8, member: 928 }, rules: [{ id: 'r3', title: 'Конфиденциальность', description: 'Не выносим закрытые материалы наружу.' }], invites: [{ id: 'i2', code: 'FOUNDERS-VIP', expiresAt: '2026-10-01', uses: 34 }], moderation: { queue: 2, status: 'open' }, stats: { chatMessages: 14200, posts: 420, videos: 88 } },
];

export const communityRepository = {
  listCommunities: async () => communities,
  createInvite: async (communityId: string) => supabase.from('community_invites').insert({ community_id: communityId }),
  updateRole: async (communityId: string, userId: string, role: string) => supabase.from('community_members').update({ role }).eq('community_id', communityId).eq('user_id', userId),
  moderate: async (communityId: string, itemId: string, action: string) => supabase.from('community_moderation_actions').insert({ community_id: communityId, item_id: itemId, action }),
  sendChatMessage: async (communityId: string, body: string) => supabase.from('community_chat_messages').insert({ community_id: communityId, body }),
  subscribe: (communityId: string, onChange: () => void) => supabase.channel(`community:${communityId}`).on('postgres_changes', { event: '*', schema: 'public', table: 'community_chat_messages', filter: `community_id=eq.${communityId}` }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'community_posts', filter: `community_id=eq.${communityId}` }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'community_videos', filter: `community_id=eq.${communityId}` }, onChange).subscribe(),
};
