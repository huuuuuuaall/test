import { LinearGradient } from 'expo-linear-gradient';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import Video from 'react-native-video';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { Avatar } from '@/shared/ui/primitives';
import { colors } from '@/shared/config/theme';
import { VideoPost } from '../model';
import { VideoActionRail } from './VideoActionRail';

export function VideoFeedItem({ video, active }: { video: VideoPost; active: boolean }) {
  const { height } = useWindowDimensions();
  return <View style={[s.page, { height }]}><Video source={{ uri: video.cachedUrl ?? video.videoUrl }} poster={video.posterUrl} paused={!active} repeat resizeMode="cover" playInBackground={false} playWhenInactive={false} style={StyleSheet.absoluteFill} /><LinearGradient colors={['rgba(0,0,0,0.04)', 'rgba(0,0,0,0.72)']} style={StyleSheet.absoluteFill} /><Animated.View entering={FadeInUp.springify()} style={s.meta}><View style={s.author}><Avatar label={video.author.avatar} size={54} /><View style={{ flex: 1 }}><Text style={s.name}>{video.author.name}</Text><Text style={s.handle}>{video.author.handle}</Text></View><Pressable style={[s.follow, video.viewer.following && s.following]}><Text style={s.followText}>{video.viewer.following ? 'Вы подписаны' : 'Подписаться'}</Text></Pressable></View><Text style={s.caption}>{video.caption}</Text><Text style={s.music}>♪ {video.music}</Text></Animated.View><VideoActionRail video={video} /></View>;
}
const s = StyleSheet.create({ page: { width: '100%', backgroundColor: '#050507' }, meta: { position: 'absolute', left: 18, right: 92, bottom: 88, gap: 12 }, author: { flexDirection: 'row', alignItems: 'center', gap: 12 }, name: { color: 'white', fontSize: 18, fontWeight: '900' }, handle: { color: 'rgba(255,255,255,0.76)', marginTop: 2 }, follow: { borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,0.5)', paddingHorizontal: 14, paddingVertical: 9, backgroundColor: colors.violet }, following: { backgroundColor: 'rgba(255,255,255,0.16)' }, followText: { color: 'white', fontWeight: '900' }, caption: { color: 'white', fontSize: 16, lineHeight: 22, fontWeight: '700' }, music: { color: 'white', fontWeight: '800' } });
