import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { colors } from '@/shared/config/theme';
import { VideoPost } from '../model';

export function VideoActionRail({ video }: { video: VideoPost }) {
  const scale = useSharedValue(1);
  const animated = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const pop = () => { scale.value = withSpring(0.86, {}, () => { scale.value = withSpring(1); }); };
  const actions = [
    { icon: video.viewer.liked ? 'heart' : 'heart-outline', value: video.stats.likes, color: video.viewer.liked ? colors.danger : 'white' },
    { icon: 'chatbubble-outline', value: video.stats.comments, color: 'white' },
    { icon: 'repeat', value: video.stats.reposts, color: 'white' },
    { icon: video.viewer.saved ? 'bookmark' : 'bookmark-outline', value: video.stats.saves, color: 'white' },
  ] as const;
  return <View style={s.rail}>{actions.map((action) => <Pressable key={action.icon} onPress={pop}><Animated.View style={[s.action, animated]}><Ionicons name={action.icon} size={32} color={action.color} /><Text style={s.value}>{action.value}</Text></Animated.View></Pressable>)}</View>;
}
const s = StyleSheet.create({ rail: { position: 'absolute', right: 16, bottom: 110, gap: 20, alignItems: 'center' }, action: { alignItems: 'center', gap: 5 }, value: { color: 'white', fontWeight: '900', textShadowColor: 'rgba(0,0,0,0.45)', textShadowRadius: 8 } });
