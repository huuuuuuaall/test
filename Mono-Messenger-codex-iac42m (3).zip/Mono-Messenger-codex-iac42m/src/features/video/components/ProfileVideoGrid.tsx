import { Ionicons } from '@expo/vector-icons';
import { ImageBackground, Pressable, StyleSheet, Text, View } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { colors, radius } from '@/shared/config/theme';
import { videoRepository } from '../api/videoRepository';

export function ProfileVideoGrid({ userId = 'me' }: { userId?: string }) {
  const videosQuery = useQuery({ queryKey: ['video', 'profile', userId], queryFn: () => videoRepository.listProfileVideos(userId) });
  return <View style={s.wrap}><Text style={s.title}>Видео автора</Text><View style={s.grid}>{(videosQuery.data ?? []).map((video) => <Pressable key={video.id} style={s.tile}><ImageBackground source={{ uri: video.posterUrl }} imageStyle={s.image} style={s.imageWrap}><View style={s.overlay}><Ionicons name="play" color="white" size={22} /><Text style={s.count}>{video.stats.likes}</Text></View></ImageBackground></Pressable>)}</View></View>;
}
const s = StyleSheet.create({ wrap: { marginTop: 18 }, title: { fontSize: 20, fontWeight: '900', color: colors.ink, marginBottom: 12 }, grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, tile: { width: '31%', aspectRatio: 0.72, borderRadius: radius.md, overflow: 'hidden', backgroundColor: '#ECECF1' }, imageWrap: { flex: 1, justifyContent: 'flex-end' }, image: { borderRadius: radius.md }, overlay: { flexDirection: 'row', alignItems: 'center', gap: 4, padding: 8, backgroundColor: 'rgba(0,0,0,0.18)' }, count: { color: 'white', fontWeight: '900' } });
