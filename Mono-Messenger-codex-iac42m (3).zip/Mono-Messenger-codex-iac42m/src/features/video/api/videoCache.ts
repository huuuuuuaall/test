import * as FileSystem from 'expo-file-system';

const cacheDirectory = `${FileSystem.cacheDirectory ?? ''}mono-video-cache/`;
const pending = new Map<string, Promise<string>>();

const fileNameForUrl = (url: string) => encodeURIComponent(url).replace(/%/g, '_');

export async function getCachedVideoUri(url: string) {
  if (!FileSystem.cacheDirectory) return url;
  const cachedUri = `${cacheDirectory}${fileNameForUrl(url)}.mp4`;
  const cachedInfo = await FileSystem.getInfoAsync(cachedUri);
  if (cachedInfo.exists) return cachedUri;
  if (!pending.has(url)) {
    pending.set(url, (async () => {
      await FileSystem.makeDirectoryAsync(cacheDirectory, { intermediates: true });
      const result = await FileSystem.downloadAsync(url, cachedUri);
      pending.delete(url);
      return result.uri;
    })());
  }
  return pending.get(url) ?? url;
}

export async function warmVideoCache(urls: string[]) {
  await Promise.allSettled(urls.slice(0, 3).map((url) => getCachedVideoUri(url)));
}
