import { supabase } from '@/shared/api/supabase';
import { VideoPost } from '../model';
import { getCachedVideoUri, warmVideoCache } from './videoCache';

const demoVideos: VideoPost[] = [
  { id: 'v1', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', posterUrl: 'https://images.unsplash.com/photo-1494526585095-c41746248156?w=1200', caption: 'Mono Video: короткие истории внутри будущей социальной платформы.', music: 'Mono — Night Drive', author: { id: 'u1', name: 'Мария Петрова', handle: '@maria', avatar: 'М', followed: false }, stats: { likes: 1800, comments: 244, reposts: 88, saves: 321 }, viewer: { liked: false, saved: true, following: false } },
  { id: 'v2', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4', posterUrl: 'https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=1200', caption: 'Большие карточки, плавные свайпы и премиальный фокус на контенте.', music: 'Mono — Soft Motion', author: { id: 'u2', name: 'Mono Design', handle: '@mono.design', avatar: 'D', followed: true }, stats: { likes: 2600, comments: 410, reposts: 120, saves: 502 }, viewer: { liked: true, saved: false, following: true } },
  { id: 'v3', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4', posterUrl: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=1200', caption: 'Видео автоматически попадают в профиль автора и живут отдельно от мессенджера.', music: 'Mono — Alpine Signal', author: { id: 'u3', name: 'Александр', handle: '@alex', avatar: 'А', followed: false }, stats: { likes: 930, comments: 79, reposts: 31, saves: 144 }, viewer: { liked: false, saved: false, following: false } },
];

export const videoRepository = {
  listFeed: async () => { void warmVideoCache(demoVideos.map((video) => video.videoUrl)); return Promise.all(demoVideos.map(async (video) => ({ ...video, cachedUrl: await getCachedVideoUri(video.videoUrl) }))); },
  listProfileVideos: async (userId: string) => demoVideos.filter((video) => video.author.id === userId || userId === 'me'),
  like: async (videoId: string) => supabase.from('video_likes').upsert({ video_id: videoId }),
  comment: async (videoId: string, body: string) => supabase.from('video_comments').insert({ video_id: videoId, body }),
  repost: async (videoId: string) => supabase.from('video_reposts').insert({ video_id: videoId }),
  save: async (videoId: string) => supabase.from('video_saves').insert({ video_id: videoId }),
  followAuthor: async (authorId: string) => supabase.from('user_follows').upsert({ following_id: authorId }),
  subscribeFeed: (onChange: () => void) => supabase.channel('video:feed').on('postgres_changes', { event: '*', schema: 'public', table: 'videos' }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'video_likes' }, onChange).on('postgres_changes', { event: '*', schema: 'public', table: 'video_comments' }, onChange).subscribe(),
};
