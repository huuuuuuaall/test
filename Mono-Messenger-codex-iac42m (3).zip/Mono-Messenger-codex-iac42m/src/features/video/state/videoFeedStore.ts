import { create } from 'zustand';

type VideoFeedState = { activeVideoId?: string; setActiveVideoId: (id: string) => void };
export const useVideoFeedStore = create<VideoFeedState>((set) => ({ activeVideoId: undefined, setActiveVideoId: (activeVideoId) => set({ activeVideoId }) }));
