export type VideoPost = {
  id: string;
  videoUrl: string;
  cachedUrl?: string;
  posterUrl: string;
  caption: string;
  music: string;
  author: { id: string; name: string; handle: string; avatar: string; followed: boolean };
  stats: { likes: number; comments: number; reposts: number; saves: number };
  viewer: { liked: boolean; saved: boolean; following: boolean };
};
