# Video feature

Standalone vertical video module for Mono. It owns playback, swipe navigation, author subscriptions, profile video surfacing, repository actions, and video cache warming.

Suggested Supabase tables: `videos`, `video_likes`, `video_comments`, `video_reposts`, `video_saves`, and `user_follows`.
