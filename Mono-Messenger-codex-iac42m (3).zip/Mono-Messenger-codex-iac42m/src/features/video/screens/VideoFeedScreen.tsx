import { FlashList } from '@shopify/flash-list';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useMemo, useRef } from 'react';
import { ActivityIndicator, StyleSheet, View, ViewToken } from 'react-native';
import { colors } from '@/shared/config/theme';
import { videoRepository } from '../api/videoRepository';
import { VideoFeedItem } from '../components/VideoFeedItem';
import { useVideoFeedStore } from '../state/videoFeedStore';

export function VideoFeedScreen() {
  const queryClient = useQueryClient();
  const activeVideoId = useVideoFeedStore((state) => state.activeVideoId);
  const setActiveVideoId = useVideoFeedStore((state) => state.setActiveVideoId);
  const feedQuery = useQuery({ queryKey: ['video', 'feed'], queryFn: videoRepository.listFeed });
  useEffect(() => { const channel = videoRepository.subscribeFeed(() => queryClient.invalidateQueries({ queryKey: ['video', 'feed'] })); return () => { channel.unsubscribe(); }; }, [queryClient]);
  useEffect(() => { if (!activeVideoId && feedQuery.data?.[0]) setActiveVideoId(feedQuery.data[0].id); }, [activeVideoId, feedQuery.data, setActiveVideoId]);
  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => { const first = viewableItems[0]?.item; if (first?.id) setActiveVideoId(first.id); }).current;
  const viewabilityConfig = useMemo(() => ({ itemVisiblePercentThreshold: 80, minimumViewTime: 120 }), []);
  if (feedQuery.isLoading) return <View style={s.loading}><ActivityIndicator color={colors.violet} size="large" /></View>;
  return <FlashList data={feedQuery.data ?? []} estimatedItemSize={820} pagingEnabled decelerationRate="fast" snapToAlignment="start" showsVerticalScrollIndicator={false} onViewableItemsChanged={onViewableItemsChanged} viewabilityConfig={viewabilityConfig} renderItem={({ item }) => <VideoFeedItem video={item} active={item.id === activeVideoId} />} />;
}
const s = StyleSheet.create({ loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#050507' } });
