export type ChatKind = 'direct' | 'group' | 'channel';
export type ThoughtKind = 'text' | 'emoji' | 'gif' | 'photo';
export type SparkSignalKind = 'message' | 'reaction' | 'shared_action';

export type Thought = {
  id: string;
  chatId: string;
  author: string;
  kind: ThoughtKind;
  text?: string;
  mediaUrl?: string;
  publishedAt: string;
  expiresAt: string;
};

export type Chat = {
  id: string;
  kind: ChatKind;
  title: string;
  subtitle: string;
  unread: number;
  time: string;
  online?: boolean;
  thought?: Thought;
  spark?: SparkActivity;
};

export type Message = { id: string; chatId: string; author: 'me' | 'them'; text?: string; media?: string; time: string };

export type SparkSignal = { id: string; kind: SparkSignalKind; label: string; weight: number; at: string };
export type SparkPrivacy = 'everyone' | 'contacts' | 'hidden';
export type SparkActivity = {
  chatId: string;
  days: number;
  intensity: 1 | 2 | 3;
  label: string;
  notification: string;
  privacy: SparkPrivacy;
  signals: SparkSignal[];
};

const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

export const myThought: Thought = {
  id: 'thought-me',
  chatId: 'me',
  author: 'Вы',
  kind: 'emoji',
  text: '🚀 Работаю над Mono',
  publishedAt: new Date().toISOString(),
  expiresAt: tomorrow,
};

export const chats: Chat[] = [
  {
    id: '1',
    kind: 'direct',
    title: 'Александр',
    subtitle: 'Привет! Как дела?',
    unread: 2,
    time: '12:30',
    online: true,
    spark: {
      chatId: '1',
      days: 12,
      intensity: 3,
      label: 'Огонёк держится 12 дней',
      notification: 'Ответьте сегодня, чтобы Огонёк стал ярче.',
      privacy: 'contacts',
      signals: [
        { id: 'spark-1-message', kind: 'message', label: '7 сообщений за сутки', weight: 7, at: new Date().toISOString() },
        { id: 'spark-1-reaction', kind: 'reaction', label: '3 реакции на медиа', weight: 3, at: new Date().toISOString() },
        { id: 'spark-1-action', kind: 'shared_action', label: 'Совместный плейлист', weight: 5, at: new Date().toISOString() },
      ],
    },
    thought: {
      id: 'thought-1',
      chatId: '1',
      author: 'Александр',
      kind: 'text',
      text: 'Думаю о выходных',
      publishedAt: new Date().toISOString(),
      expiresAt: tomorrow,
    },
  },
  {
    id: '2',
    kind: 'group',
    title: 'Дизайн-команда',
    subtitle: 'Скетч обновлен',
    unread: 5,
    time: '11:45',
    spark: {
      chatId: '2',
      days: 5,
      intensity: 2,
      label: 'Командный Огонёк 5 дней',
      notification: 'Созвон или реакция продлят серию команды.',
      privacy: 'contacts',
      signals: [
        { id: 'spark-2-message', kind: 'message', label: 'Обсуждение макетов', weight: 6, at: new Date().toISOString() },
        { id: 'spark-2-action', kind: 'shared_action', label: 'Общий файл обновлен', weight: 4, at: new Date().toISOString() },
      ],
    },
    thought: {
      id: 'thought-2',
      chatId: '2',
      author: 'Дизайн-команда',
      kind: 'gif',
      text: 'Брейншторм в процессе',
      mediaUrl: 'GIF',
      publishedAt: new Date().toISOString(),
      expiresAt: tomorrow,
    },
  },
  {
    id: '3',
    kind: 'channel',
    title: 'Канал новостей',
    subtitle: 'У нас свежие новости',
    unread: 1,
    time: '10:15',
    spark: {
      chatId: '3',
      days: 2,
      intensity: 1,
      label: 'Огонёк читателей 2 дня',
      notification: 'Реакция на выпуск засчитывается в активность.',
      privacy: 'everyone',
      signals: [
        { id: 'spark-3-reaction', kind: 'reaction', label: 'Реакции на новости', weight: 2, at: new Date().toISOString() },
      ],
    },
    thought: {
      id: 'thought-3',
      chatId: '3',
      author: 'Канал новостей',
      kind: 'photo',
      text: 'Фото дня',
      mediaUrl: '📷',
      publishedAt: new Date().toISOString(),
      expiresAt: tomorrow,
    },
  },
];

export const thoughts = [myThought, ...chats.flatMap((chat) => (chat.thought ? [chat.thought] : []))];
export const sparkPrivacySettings = [
  { id: 'visibility', title: 'Кто видит мой Огонёк', value: 'Только контакты' },
  { id: 'notifications', title: 'Уведомления об угасании', value: 'За 6 часов' },
  { id: 'signals', title: 'Учитывать совместные действия', value: 'Включено' },
];

export const messages: Message[] = [
  { id: 'm1', chatId: '1', author: 'them', text: 'Привет! Как дела?', time: '12:30' },
  { id: 'm2', chatId: '1', author: 'me', text: 'Привет! Всё отлично, спасибо!', time: '12:30' },
  { id: 'm3', chatId: '1', author: 'them', text: 'Что нового?', time: '12:32' },
];
