import { supabase } from '@/shared/api/supabase';
import { chats, messages } from './model';
export const messengerRepository = {
  listChats: async () => chats,
  listMessages: async (chatId: string) => messages.filter((m) => m.chatId === chatId),
  subscribeChat: (chatId: string, onChange: () => void) => supabase.channel(`chat:${chatId}`).on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `chat_id=eq.${chatId}` }, onChange).subscribe(),
};
