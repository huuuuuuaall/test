Reserved feature module for social feed. Keep repositories, screens, and domain logic isolated here.
