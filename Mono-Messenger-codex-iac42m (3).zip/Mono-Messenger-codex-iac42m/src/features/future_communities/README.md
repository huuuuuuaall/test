Reserved feature module for communities and public spaces.
