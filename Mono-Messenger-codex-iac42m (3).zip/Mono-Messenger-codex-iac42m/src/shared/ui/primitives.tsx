import { LinearGradient } from 'expo-linear-gradient';
import { PropsWithChildren } from 'react';
import { Pressable, StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { colors, radius, shadow } from '@/shared/config/theme';

export const Screen = ({ children }: PropsWithChildren) => <LinearGradient colors={['#FFFFFF', '#F6F6FA']} style={s.screen}>{children}</LinearGradient>;
export const Card = ({ children }: PropsWithChildren) => <Animated.View entering={FadeInDown.springify()} style={s.card}>{children}</Animated.View>;
export const Title = ({ children }: PropsWithChildren) => <Text style={s.title}>{children}</Text>;
export const Muted = ({ children }: PropsWithChildren) => <Text style={s.muted}>{children}</Text>;
export const Field = (props: TextInputProps) => <TextInput placeholderTextColor="#A5A7B0" style={s.field} {...props} />;
export const Button = ({ children, onPress }: PropsWithChildren<{ onPress?: () => void }>) => <Pressable onPress={onPress} style={({ pressed }) => [s.button, pressed && { transform: [{ scale: 0.98 }] }]}><Text style={s.buttonText}>{children}</Text></Pressable>;
export const Avatar = ({ label, size = 56 }: { label: string; size?: number }) => <View style={[s.avatar, { width: size, height: size, borderRadius: size / 2 }]}><Text style={s.avatarText}>{label.slice(0, 1)}</Text></View>;
const s = StyleSheet.create({ screen: { flex: 1, padding: 20 }, card: { backgroundColor: colors.card, borderRadius: radius.lg, padding: 20, ...shadow }, title: { fontSize: 28, fontWeight: '800', color: colors.ink, letterSpacing: -0.8 }, muted: { color: colors.muted, fontSize: 14, marginTop: 6 }, field: { height: 56, borderRadius: 18, backgroundColor: '#F3F3F6', paddingHorizontal: 18, fontSize: 16, marginTop: 12 }, button: { height: 58, borderRadius: 19, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center', marginTop: 18 }, buttonText: { color: 'white', fontWeight: '800', fontSize: 16 }, avatar: { backgroundColor: colors.violet, alignItems: 'center', justifyContent: 'center' }, avatarText: { color: 'white', fontWeight: '900', fontSize: 22 } });
