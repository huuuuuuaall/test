export const colors = { ink: '#111113', muted: '#777A83', line: '#ECECF1', bg: '#F8F8FB', card: '#FFFFFF', violet: '#7C5CFF', violet2: '#A996FF', danger: '#FF3B4E', green: '#34C759' };
export const radius = { sm: 14, md: 22, lg: 30, xl: 38 };
export const shadow = { shadowColor: '#14141F', shadowOpacity: 0.08, shadowRadius: 28, shadowOffset: { width: 0, height: 16 }, elevation: 8 };
